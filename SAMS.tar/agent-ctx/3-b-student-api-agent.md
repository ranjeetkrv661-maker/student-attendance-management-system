# Task 3-b: Student API Routes for Viewing Attendance

## Summary
Created 3 API route files under `/api/student/` for student attendance viewing features.

## Files Created

| File | Purpose |
|------|---------|
| `src/app/api/student/attendance/route.ts` | GET attendance records with subject/date filters, overall & per-subject percentages, < 75% warnings |
| `src/app/api/student/dashboard/route.ts` | GET complete dashboard summary: student info, overall stats, subject breakdown, recent records |
| `src/app/api/student/attendance-chart/route.ts` | GET chart-ready data: monthly summary (3 months), subject-wise %, weekly trend |

## API Endpoints

### GET /api/student/attendance
- **Required**: `studentId`
- **Optional**: `subjectId`, `fromDate` (YYYY-MM-DD), `toDate` (YYYY-MM-DD)
- **Returns**: records with subject info, overall percentage, per-subject breakdown with warnings

### GET /api/student/dashboard
- **Required**: `studentId`
- **Returns**: student info, overall stats, subject breakdown, last 10 records, low attendance warning

### GET /api/student/attendance-chart
- **Required**: `studentId`
- **Returns**: monthlySummary (3 months), subjectWiseAttendance, weeklyTrend

## Design Decisions
- Division-by-zero safe (returns 0% when no records)
- Date validation with YYYY-MM-DD regex
- < 75% attendance flagged as `warning: true`
- Months formatted as readable labels ("Jan 2024") for chart UI
- Weeks use ISO Monday as start
- Follows existing code patterns from Task 3-a

## Lint Status
✅ Clean — no errors
