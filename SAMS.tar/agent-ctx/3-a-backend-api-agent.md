# Task 3-a: Authentication and Seed API Routes

## Summary
Created all 4 API route files for authentication and database seeding.

## Files Created

| File | Purpose |
|------|---------|
| `src/app/api/auth/login/route.ts` | POST login with email/password |
| `src/app/api/auth/me/route.ts` | GET user with role-specific data by userId |
| `src/app/api/seed/route.ts` | POST to seed DB with Indian college sample data |
| `src/app/api/auth/profile/route.ts` | GET full profile with attendance stats (students), subjects (teachers), or basic info (admin) |

## Design Decisions
- Plain text password comparison (no hashing, per project requirements)
- No session/cookie management — client stores user state in Zustand
- Upsert with fixed IDs for idempotent seeding
- Deterministic pseudo-random attendance generation (~80% PRESENT, ~20% ABSENT)
- Sundays skipped in attendance generation (no college on Sundays)
- Password always excluded from API responses

## Lint Status
✅ Clean — no errors

## Database
✅ Schema already in sync with Prisma
