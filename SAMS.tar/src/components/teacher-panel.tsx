'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  BookOpen, Users, ClipboardList, LogOut, CheckCircle2, XCircle,
  Calendar, ChevronDown, ChevronUp, Loader2, GraduationCap,
  Clock, BarChart3, Save, UserCheck, UserX
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { useToast } from '@/hooks/use-toast'
import { Checkbox } from '@/components/ui/checkbox'

// ============================================================
// Types
// ============================================================

interface TeacherPanelProps {
  userId: string
  userName: string
  onLogout: () => void
}

/** Shape returned by GET /api/teacher/dashboard */
interface DashboardData {
  totalClasses: number
  totalStudents: number
  recentAttendance: {
    id: string
    date: string
    status: string
    studentName: string
    rollNo: string
    className: string
    subjectName: string
  }[]
  classList: {
    id: string
    className: string
    studentCount: number
    subjects: { id: string; subjectName: string }[]
  }[]
}

/** Shape returned by GET /api/teacher/classes */
interface ClassOption {
  id: string
  className: string
  subjects: { id: string; subjectName: string }[]
}

/** Shape returned by GET /api/teacher/subjects */
interface SubjectOption {
  id: string
  subjectName: string
  assignmentId: string
}

/** Shape returned by GET /api/teacher/students */
interface StudentInfo {
  id: string
  rollNo: string
  name: string
  email: string
}

/** Shape returned by GET /api/teacher/attendance/check */
interface AttendanceCheckResult {
  exists: boolean
  records: {
    id: string
    studentId: string
    studentName: string
    rollNo: string
    status: string
  }[]
}

/** Shape returned by GET /api/teacher/history */
interface HistoryGroup {
  date: string
  className: string
  subjectName: string
  records: {
    studentId: string
    studentName: string
    rollNo: string
    status: string
  }[]
  totalStudents: number
  presentCount: number
  absentCount: number
}

// ============================================================
// Helper: format a date string for display
// ============================================================
function formatDateDisplay(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00')
  return d.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}

/** Get today's date in YYYY-MM-DD format */
function getTodayStr(): string {
  const d = new Date()
  return d.toISOString().slice(0, 10)
}

// ============================================================
// Main Component
// ============================================================

export default function TeacherPanel({ userId, userName, onLogout }: TeacherPanelProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState('dashboard')

  // ────────────────────────────────────────
  // Dashboard state
  // ────────────────────────────────────────
  const [dashboard, setDashboard] = useState<DashboardData | null>(null)
  const [dashboardLoading, setDashboardLoading] = useState(true)

  // ────────────────────────────────────────
  // Mark Attendance state
  // ────────────────────────────────────────
  const [classes, setClasses] = useState<ClassOption[]>([])
  const [selectedClassId, setSelectedClassId] = useState('')
  const [subjects, setSubjects] = useState<SubjectOption[]>([])
  const [selectedSubjectId, setSelectedSubjectId] = useState('')
  const [selectedDate, setSelectedDate] = useState(getTodayStr())
  const [students, setStudents] = useState<StudentInfo[]>([])
  const [attendanceMap, setAttendanceMap] = useState<Record<string, string>>({}) // studentId -> PRESENT | ABSENT
  const [existingAttendance, setExistingAttendance] = useState<AttendanceCheckResult | null>(null)
  const [markStep, setMarkStep] = useState(1) // 1: select class, 2: select subject, 3: select date, 4: mark
  const [markLoading, setMarkLoading] = useState(false)
  const [savingAttendance, setSavingAttendance] = useState(false)

  // ────────────────────────────────────────
  // History state
  // ────────────────────────────────────────
  const [historyClasses, setHistoryClasses] = useState<ClassOption[]>([])
  const [historySubjects, setHistorySubjects] = useState<SubjectOption[]>([])
  const [historyClassId, setHistoryClassId] = useState('')
  const [historySubjectId, setHistorySubjectId] = useState('')
  const [historyFromDate, setHistoryFromDate] = useState('')
  const [historyToDate, setHistoryToDate] = useState('')
  const [history, setHistory] = useState<HistoryGroup[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)
  const [expandedDate, setExpandedDate] = useState<string | null>(null)

  // ============================================================
  // Fetch dashboard data
  // ============================================================
  const fetchDashboard = useCallback(async () => {
    setDashboardLoading(true)
    try {
      const res = await fetch(`/api/teacher/dashboard?teacherId=${userId}`)
      if (!res.ok) throw new Error('Failed to fetch dashboard')
      const data = await res.json()
      setDashboard(data)
    } catch {
      toast({ title: 'Error', description: 'Failed to load dashboard data', variant: 'destructive' })
    } finally {
      setDashboardLoading(false)
    }
  }, [userId, toast])

  // ============================================================
  // Fetch classes for Mark Attendance tab
  // ============================================================
  const fetchClasses = useCallback(async () => {
    try {
      const res = await fetch(`/api/teacher/classes?teacherId=${userId}`)
      if (!res.ok) throw new Error('Failed to fetch classes')
      const data = await res.json()
      setClasses(data.classes)
    } catch {
      toast({ title: 'Error', description: 'Failed to load classes', variant: 'destructive' })
    }
  }, [userId, toast])

  // ============================================================
  // Fetch subjects for selected class (Mark Attendance)
  // ============================================================
  const fetchSubjects = useCallback(async (classId: string) => {
    try {
      const res = await fetch(`/api/teacher/subjects?teacherId=${userId}&classId=${classId}`)
      if (!res.ok) throw new Error('Failed to fetch subjects')
      const data = await res.json()
      setSubjects(data.subjects)
    } catch {
      toast({ title: 'Error', description: 'Failed to load subjects', variant: 'destructive' })
    }
  }, [userId, toast])

  // ============================================================
  // Fetch students + check existing attendance (Mark Attendance)
  // ============================================================
  const fetchStudentsAndCheck = useCallback(async (classId: string, subjectId: string, date: string) => {
    setMarkLoading(true)
    try {
      // Fetch students in parallel with attendance check
      const [studentsRes, checkRes] = await Promise.all([
        fetch(`/api/teacher/students?classId=${classId}`),
        fetch(`/api/teacher/attendance/check?classId=${classId}&subjectId=${subjectId}&date=${date}`),
      ])

      if (!studentsRes.ok) throw new Error('Failed to fetch students')
      const studentsData = await studentsRes.json()
      setStudents(studentsData.students)

      if (!checkRes.ok) throw new Error('Failed to check attendance')
      const checkData: AttendanceCheckResult = await checkRes.json()
      setExistingAttendance(checkData)

      // Build attendance map: pre-fill from existing records or default all to PRESENT
      const newMap: Record<string, string> = {}
      for (const student of studentsData.students as StudentInfo[]) {
        const existing = checkData.records.find((r) => r.studentId === student.id)
        newMap[student.id] = existing ? existing.status : 'PRESENT'
      }
      setAttendanceMap(newMap)
    } catch {
      toast({ title: 'Error', description: 'Failed to load student data', variant: 'destructive' })
    } finally {
      setMarkLoading(false)
    }
  }, [toast])

  // ============================================================
  // Save attendance
  // ============================================================
  const saveAttendance = async () => {
    if (!selectedClassId || !selectedSubjectId || !selectedDate) return

    setSavingAttendance(true)
    try {
      const records = Object.entries(attendanceMap).map(([studentId, status]) => ({
        studentId,
        status,
      }))

      const res = await fetch('/api/teacher/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teacherId: userId,
          classId: selectedClassId,
          subjectId: selectedSubjectId,
          date: selectedDate,
          records,
        }),
      })

      if (!res.ok) {
        const errorData = await res.json()
        throw new Error(errorData.error || 'Failed to save attendance')
      }

      const result = await res.json()
      toast({
        title: 'Success!',
        description: `Attendance saved for ${result.count} students on ${formatDateDisplay(selectedDate)}`,
      })

      // Refresh dashboard to show updated recent records
      fetchDashboard()
    } catch (err) {
      toast({
        title: 'Error',
        description: err instanceof Error ? err.message : 'Failed to save attendance',
        variant: 'destructive',
      })
    } finally {
      setSavingAttendance(false)
    }
  }

  // ============================================================
  // Fetch attendance history
  // ============================================================
  const fetchHistory = useCallback(async () => {
    setHistoryLoading(true)
    try {
      const params = new URLSearchParams({ teacherId: userId })
      if (historyClassId) params.set('classId', historyClassId)
      if (historySubjectId) params.set('subjectId', historySubjectId)
      if (historyFromDate) params.set('fromDate', historyFromDate)
      if (historyToDate) params.set('toDate', historyToDate)

      const res = await fetch(`/api/teacher/history?${params.toString()}`)
      if (!res.ok) throw new Error('Failed to fetch history')
      const data = await res.json()
      setHistory(data.history || [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load attendance history', variant: 'destructive' })
    } finally {
      setHistoryLoading(false)
    }
  }, [userId, historyClassId, historySubjectId, historyFromDate, historyToDate, toast])

  // ============================================================
  // Effects — initial data loads
  // ============================================================
  useEffect(() => {
    fetchDashboard()
  }, [fetchDashboard])

  // When switching to Mark Attendance tab, load classes
  useEffect(() => {
    if (activeTab === 'mark') {
      fetchClasses()
    }
  }, [activeTab, fetchClasses])

  // When switching to History tab, load classes for filter
  useEffect(() => {
    if (activeTab === 'history') {
      // Reuse the classes fetch for history filters
      const loadHistoryClasses = async () => {
        try {
          const res = await fetch(`/api/teacher/classes?teacherId=${userId}`)
          if (res.ok) {
            const data = await res.json()
            setHistoryClasses(data.classes)
          }
        } catch {
          // silent
        }
      }
      loadHistoryClasses()
      fetchHistory()
    }
  }, [activeTab])

  // When history class changes, update subjects for that class
  useEffect(() => {
    if (activeTab !== 'history' || !historyClassId) {
      setHistorySubjects([])
      return
    }
    const loadSubjects = async () => {
      try {
        const res = await fetch(`/api/teacher/subjects?teacherId=${userId}&classId=${historyClassId}`)
        if (res.ok) {
          const data = await res.json()
          setHistorySubjects(data.subjects)
        }
      } catch {
        // silent
      }
    }
    loadSubjects()
  }, [activeTab, historyClassId, userId])

  // Fetch history when filters change
  useEffect(() => {
    if (activeTab === 'history') {
      fetchHistory()
    }
  }, [historyClassId, historySubjectId, historyFromDate, historyToDate, fetchHistory])

  // ============================================================
  // Mark Attendance handlers
  // ============================================================
  const handleClassSelect = async (classId: string) => {
    setSelectedClassId(classId)
    setSelectedSubjectId('')
    setSubjects([])
    setStudents([])
    setAttendanceMap({})
    setExistingAttendance(null)
    setMarkStep(2)
    if (classId) {
      await fetchSubjects(classId)
    }
  }

  const handleSubjectSelect = (subjectId: string) => {
    setSelectedSubjectId(subjectId)
    setMarkStep(3)
  }

  const handleProceedToMark = () => {
    if (!selectedClassId || !selectedSubjectId || !selectedDate) return
    setMarkStep(4)
    fetchStudentsAndCheck(selectedClassId, selectedSubjectId, selectedDate)
  }

  const toggleStudentAttendance = (studentId: string) => {
    setAttendanceMap((prev) => ({
      ...prev,
      [studentId]: prev[studentId] === 'PRESENT' ? 'ABSENT' : 'PRESENT',
    }))
  }

  const markAllPresent = () => {
    const newMap: Record<string, string> = {}
    for (const student of students) {
      newMap[student.id] = 'PRESENT'
    }
    setAttendanceMap(newMap)
  }

  const markAllAbsent = () => {
    const newMap: Record<string, string> = {}
    for (const student of students) {
      newMap[student.id] = 'ABSENT'
    }
    setAttendanceMap(newMap)
  }

  const resetMarkAttendance = () => {
    setSelectedClassId('')
    setSelectedSubjectId('')
    setSelectedDate(getTodayStr())
    setSubjects([])
    setStudents([])
    setAttendanceMap({})
    setExistingAttendance(null)
    setMarkStep(1)
  }

  // ============================================================
  // Compute present/absent counts for the current attendance form
  // ============================================================
  const presentCount = Object.values(attendanceMap).filter((s) => s === 'PRESENT').length
  const absentCount = Object.values(attendanceMap).filter((s) => s === 'ABSENT').length
  const attendancePercentage = students.length > 0 ? Math.round((presentCount / students.length) * 100) : 0

  // Find selected class and subject names for display
  const selectedClassName = classes.find((c) => c.id === selectedClassId)?.className || ''
  const selectedSubjectName = subjects.find((s) => s.id === selectedSubjectId)?.subjectName || ''

  // ============================================================
  // RENDER
  // ============================================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-green-50">
      {/* ──── Header ──── */}
      <header className="sticky top-0 z-30 border-b bg-white/80 backdrop-blur-md shadow-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Attendance System</h1>
              <p className="text-xs text-gray-500">Teacher Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <p className="text-sm font-medium text-gray-900">{userName}</p>
              <p className="text-xs text-gray-500">Teacher</p>
            </div>
            <Button variant="outline" size="sm" onClick={onLogout} className="text-red-600 hover:bg-red-50 hover:text-red-700">
              <LogOut className="mr-1 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* ──── Main Content ──── */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-emerald-100/60">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <BarChart3 className="mr-1 h-4 w-4 hidden sm:inline" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="mark" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <ClipboardList className="mr-1 h-4 w-4 hidden sm:inline" />
              Mark Attendance
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
              <Clock className="mr-1 h-4 w-4 hidden sm:inline" />
              History
            </TabsTrigger>
          </TabsList>

          {/* ════════════════════════════════════════════
              DASHBOARD TAB
              ════════════════════════════════════════════ */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Welcome */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Welcome, {userName}! 👋</h2>
              <p className="text-gray-500 mt-1">Here&apos;s your attendance overview</p>
            </div>

            {/* Stat Cards */}
            {dashboardLoading ? (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-20 rounded bg-gray-200" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : dashboard ? (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                {/* Total Classes */}
                <Card className="border-l-4 border-l-emerald-500 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500">Total Classes</p>
                        <p className="mt-1 text-3xl font-bold text-gray-900">{dashboard.totalClasses}</p>
                      </div>
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100">
                        <BookOpen className="h-6 w-6 text-emerald-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Total Students */}
                <Card className="border-l-4 border-l-teal-500 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500">Total Students</p>
                        <p className="mt-1 text-3xl font-bold text-gray-900">{dashboard.totalStudents}</p>
                      </div>
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-teal-100">
                        <Users className="h-6 w-6 text-teal-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Attendance Records */}
                <Card className="border-l-4 border-l-green-500 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500">Attendance Records</p>
                        <p className="mt-1 text-3xl font-bold text-gray-900">{dashboard.recentAttendance.length}</p>
                        <p className="text-xs text-gray-400">recent entries</p>
                      </div>
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                        <ClipboardList className="h-6 w-6 text-green-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : null}

            {/* Recent Attendance */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5 text-emerald-600" />
                  Recent Attendance Records
                </CardTitle>
                <CardDescription>Last 5 attendance entries across your classes</CardDescription>
              </CardHeader>
              <CardContent>
                {dashboardLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-12 animate-pulse rounded bg-gray-100" />
                    ))}
                  </div>
                ) : dashboard && dashboard.recentAttendance.length === 0 ? (
                  <div className="py-8 text-center text-gray-400">
                    <ClipboardList className="mx-auto h-12 w-12 mb-2" />
                    <p>No attendance records yet</p>
                    <p className="text-sm">Start by marking attendance in the &quot;Mark Attendance&quot; tab</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead>Roll No</TableHead>
                          <TableHead>Class</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dashboard?.recentAttendance.map((rec) => (
                          <TableRow key={rec.id}>
                            <TableCell className="font-medium">{formatDateDisplay(rec.date)}</TableCell>
                            <TableCell>{rec.studentName}</TableCell>
                            <TableCell>{rec.rollNo}</TableCell>
                            <TableCell>{rec.className}</TableCell>
                            <TableCell>{rec.subjectName}</TableCell>
                            <TableCell>
                              {rec.status === 'PRESENT' ? (
                                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border-0">
                                  <CheckCircle2 className="mr-1 h-3 w-3" /> Present
                                </Badge>
                              ) : (
                                <Badge variant="destructive" className="bg-red-100 text-red-700 hover:bg-red-200 border-0">
                                  <XCircle className="mr-1 h-3 w-3" /> Absent
                                </Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ════════════════════════════════════════════
              MARK ATTENDANCE TAB
              ════════════════════════════════════════════ */}
          <TabsContent value="mark" className="space-y-6">
            {/* Step indicator */}
            <Card className="shadow-sm">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">Mark Attendance</h2>
                    <p className="text-sm text-gray-500">Follow the steps below to record attendance</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={resetMarkAttendance} className="self-start">
                    Reset Form
                  </Button>
                </div>

                {/* Progress Steps */}
                <div className="mb-6">
                  <Progress value={(markStep / 4) * 100} className="h-2" />
                  <div className="mt-2 flex justify-between text-xs text-gray-500">
                    <span className={markStep >= 1 ? 'font-semibold text-emerald-600' : ''}>1. Select Class</span>
                    <span className={markStep >= 2 ? 'font-semibold text-emerald-600' : ''}>2. Select Subject</span>
                    <span className={markStep >= 3 ? 'font-semibold text-emerald-600' : ''}>3. Select Date</span>
                    <span className={markStep >= 4 ? 'font-semibold text-emerald-600' : ''}>4. Mark Attendance</span>
                  </div>
                </div>

                {/* Step 1: Select Class */}
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    {/* Class Selector */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1">
                        <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold ${markStep >= 1 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'}`}>1</span>
                        Select Class
                      </Label>
                      <Select value={selectedClassId} onValueChange={handleClassSelect} disabled={classes.length === 0}>
                        <SelectTrigger>
                          <SelectValue placeholder={classes.length === 0 ? 'Loading...' : 'Choose a class'} />
                        </SelectTrigger>
                        <SelectContent>
                          {classes.map((cls) => (
                            <SelectItem key={cls.id} value={cls.id}>
                              {cls.className}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Subject Selector (Step 2) */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1">
                        <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold ${markStep >= 2 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'}`}>2</span>
                        Select Subject
                      </Label>
                      <Select
                        value={selectedSubjectId}
                        onValueChange={handleSubjectSelect}
                        disabled={markStep < 2 || subjects.length === 0}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={markStep < 2 ? 'Select class first' : subjects.length === 0 ? 'No subjects' : 'Choose a subject'} />
                        </SelectTrigger>
                        <SelectContent>
                          {subjects.map((sub) => (
                            <SelectItem key={sub.id} value={sub.id}>
                              {sub.subjectName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Date Selector (Step 3) */}
                    <div className="space-y-2">
                      <Label className="flex items-center gap-1">
                        <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs font-bold ${markStep >= 3 ? 'bg-emerald-600 text-white' : 'bg-gray-200 text-gray-500'}`}>3</span>
                        Select Date
                      </Label>
                      <Input
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        disabled={markStep < 3}
                        className="w-full"
                      />
                    </div>
                  </div>

                  {/* Proceed Button */}
                  {markStep >= 3 && selectedClassId && selectedSubjectId && selectedDate && markStep < 4 && (
                    <Button
                      onClick={handleProceedToMark}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white"
                      disabled={markLoading}
                    >
                      {markLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Loading...
                        </>
                      ) : (
                        <>
                          Proceed to Mark Attendance
                          <ChevronDown className="ml-1 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Step 4: Student List & Attendance Marking */}
            {markStep === 4 && (
              <>
                {/* Existing attendance notice */}
                {existingAttendance?.exists && (
                  <Alert className="border-amber-300 bg-amber-50">
                    <Calendar className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-amber-800">
                      Attendance for <strong>{selectedSubjectName}</strong> in <strong>{selectedClassName}</strong> on{' '}
                      <strong>{formatDateDisplay(selectedDate)}</strong> was already marked. You can edit the records below.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Summary bar */}
                <Card className="shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {selectedClassName} — {selectedSubjectName}
                        </h3>
                        <p className="text-sm text-gray-500">{formatDateDisplay(selectedDate)}</p>
                      </div>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1 text-emerald-600 font-medium">
                          <UserCheck className="h-4 w-4" /> {presentCount} Present
                        </span>
                        <span className="flex items-center gap-1 text-red-600 font-medium">
                          <UserX className="h-4 w-4" /> {absentCount} Absent
                        </span>
                        <span className="flex items-center gap-1 text-gray-600 font-medium">
                          {attendancePercentage}% Attendance
                        </span>
                      </div>
                    </div>
                    <Progress value={attendancePercentage} className="mt-3 h-2" />
                  </CardContent>
                </Card>

                {/* Quick actions + Student list */}
                <Card className="shadow-sm">
                  <CardHeader className="pb-3">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <CardTitle className="text-lg">Student List</CardTitle>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={markAllPresent}
                          className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                        >
                          <UserCheck className="mr-1 h-4 w-4" />
                          Mark All Present
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={markAllAbsent}
                          className="border-red-300 text-red-700 hover:bg-red-50"
                        >
                          <UserX className="mr-1 h-4 w-4" />
                          Mark All Absent
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {markLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
                        <span className="ml-3 text-gray-500">Loading students...</span>
                      </div>
                    ) : students.length === 0 ? (
                      <div className="py-8 text-center text-gray-400">
                        <Users className="mx-auto h-12 w-12 mb-2" />
                        <p>No students found in this class</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-16">Roll No</TableHead>
                              <TableHead>Student Name</TableHead>
                              <TableHead className="w-24 text-center">Present</TableHead>
                              <TableHead className="w-24 text-center">Absent</TableHead>
                              <TableHead className="w-24 text-center">Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {students.map((student) => {
                              const isPresent = attendanceMap[student.id] === 'PRESENT'
                              return (
                                <TableRow key={student.id} className={isPresent ? 'bg-emerald-50/50' : 'bg-red-50/50'}>
                                  <TableCell className="font-mono font-medium">{student.rollNo}</TableCell>
                                  <TableCell className="font-medium">{student.name}</TableCell>
                                  <TableCell className="text-center">
                                    <Checkbox
                                      checked={isPresent}
                                      onCheckedChange={() => toggleStudentAttendance(student.id)}
                                      className="h-5 w-5 data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                                    />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Checkbox
                                      checked={!isPresent}
                                      onCheckedChange={() => toggleStudentAttendance(student.id)}
                                      className="h-5 w-5 data-[state=checked]:bg-red-500 data-[state=checked]:border-red-500"
                                    />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    {isPresent ? (
                                      <Badge className="bg-emerald-100 text-emerald-700 border-0 hover:bg-emerald-200">
                                        Present
                                      </Badge>
                                    ) : (
                                      <Badge className="bg-red-100 text-red-700 border-0 hover:bg-red-200">
                                        Absent
                                      </Badge>
                                    )}
                                  </TableCell>
                                </TableRow>
                              )
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    {/* Save Button */}
                    {students.length > 0 && (
                      <div className="mt-6 flex justify-end">
                        <Button
                          onClick={saveAttendance}
                          disabled={savingAttendance}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white px-8"
                          size="lg"
                        >
                          {savingAttendance ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="mr-2 h-4 w-4" />
                              Save Attendance
                            </>
                          )}
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* ════════════════════════════════════════════
              ATTENDANCE HISTORY TAB
              ════════════════════════════════════════════ */}
          <TabsContent value="history" className="space-y-6">
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Clock className="h-5 w-5 text-emerald-600" />
                  Attendance History
                </CardTitle>
                <CardDescription>View and filter past attendance records</CardDescription>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {/* Class Filter */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">Class</Label>
                    <Select value={historyClassId} onValueChange={(v) => { setHistoryClassId(v); setHistorySubjectId(''); }}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Classes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {historyClasses.map((cls) => (
                          <SelectItem key={cls.id} value={cls.id}>
                            {cls.className}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Subject Filter */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">Subject</Label>
                    <Select value={historySubjectId} onValueChange={setHistorySubjectId} disabled={!historyClassId || historyClassId === 'all'}>
                      <SelectTrigger>
                        <SelectValue placeholder={!historyClassId || historyClassId === 'all' ? 'Select class first' : historySubjects.length === 0 ? 'No subjects' : 'All Subjects'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Subjects</SelectItem>
                        {historySubjects.map((sub) => (
                          <SelectItem key={sub.id} value={sub.id}>
                            {sub.subjectName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* From Date */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">From Date</Label>
                    <Input
                      type="date"
                      value={historyFromDate}
                      onChange={(e) => setHistoryFromDate(e.target.value)}
                    />
                  </div>

                  {/* To Date */}
                  <div className="space-y-1.5">
                    <Label className="text-sm">To Date</Label>
                    <Input
                      type="date"
                      value={historyToDate}
                      onChange={(e) => setHistoryToDate(e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* History Results */}
            {historyLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
                <span className="ml-3 text-gray-500">Loading history...</span>
              </div>
            ) : history.length === 0 ? (
              <Card className="shadow-sm">
                <CardContent className="py-12 text-center text-gray-400">
                  <Clock className="mx-auto h-12 w-12 mb-2" />
                  <p>No attendance records found</p>
                  <p className="text-sm mt-1">Try adjusting the filters above</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {history.map((group, idx) => {
                  // Create a unique expand key from date+className+subjectName
                  const expandKey = `${group.date}_${group.className}_${group.subjectName}_${idx}`
                  const isExpanded = expandedDate === expandKey
                  const groupPercentage = group.totalStudents > 0
                    ? Math.round((group.presentCount / group.totalStudents) * 100)
                    : 0

                  return (
                    <Card key={expandKey} className="shadow-sm overflow-hidden">
                      {/* Summary row — clickable to expand */}
                      <div
                        className="cursor-pointer hover:bg-gray-50 transition-colors"
                        onClick={() => setExpandedDate(isExpanded ? null : expandKey)}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault()
                            setExpandedDate(isExpanded ? null : expandKey)
                          }
                        }}
                      >
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100">
                                <Calendar className="h-5 w-5 text-emerald-600" />
                              </div>
                              <div>
                                <p className="font-semibold text-gray-900">{formatDateDisplay(group.date)}</p>
                                <p className="text-sm text-gray-500">
                                  {group.subjectName} • {group.className}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <div className="flex items-center gap-2">
                                  <Badge className="bg-emerald-100 text-emerald-700 border-0">
                                    <UserCheck className="mr-1 h-3 w-3" />
                                    {group.presentCount}
                                  </Badge>
                                  <span className="text-gray-400">/</span>
                                  <Badge variant="outline" className="text-gray-600">
                                    {group.totalStudents}
                                  </Badge>
                                </div>
                                <p className="mt-1 text-xs text-gray-500">
                                  {groupPercentage}% attendance
                                </p>
                              </div>
                              <Separator orientation="vertical" className="h-8 hidden sm:block" />
                              {isExpanded ? (
                                <ChevronUp className="h-5 w-5 text-gray-400" />
                              ) : (
                                <ChevronDown className="h-5 w-5 text-gray-400" />
                              )}
                            </div>
                          </div>
                          {/* Mini progress bar */}
                          <Progress value={groupPercentage} className="mt-3 h-1.5" />
                        </CardContent>
                      </div>

                      {/* Expanded: detailed student-wise attendance */}
                      {isExpanded && (
                        <div className="border-t bg-gray-50/50">
                          <CardContent className="p-4">
                            <div className="overflow-x-auto">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="w-16">Roll No</TableHead>
                                    <TableHead>Student Name</TableHead>
                                    <TableHead className="w-24 text-center">Status</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {group.records.map((rec) => (
                                    <TableRow key={rec.studentId}>
                                      <TableCell className="font-mono">{rec.rollNo}</TableCell>
                                      <TableCell>{rec.studentName}</TableCell>
                                      <TableCell className="text-center">
                                        {rec.status === 'PRESENT' ? (
                                          <Badge className="bg-emerald-100 text-emerald-700 border-0">
                                            <CheckCircle2 className="mr-1 h-3 w-3" /> Present
                                          </Badge>
                                        ) : (
                                          <Badge className="bg-red-100 text-red-700 border-0">
                                            <XCircle className="mr-1 h-3 w-3" /> Absent
                                          </Badge>
                                        )}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                          </CardContent>
                        </div>
                      )}
                    </Card>
                  )
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* ──── Footer ──── */}
      <footer className="mt-auto border-t bg-white py-4 text-center text-sm text-gray-400">
        Student Attendance Management System • Teacher Panel
      </footer>
    </div>
  )
}
