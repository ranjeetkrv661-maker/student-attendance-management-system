'use client'

import { useState, useEffect, useCallback } from 'react'
import { useToast } from '@/hooks/use-toast'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Progress } from '@/components/ui/progress'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Input } from '@/components/ui/input'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts'
import {
  LogOut,
  User,
  GraduationCap,
  Calendar,
  TrendingUp,
  Download,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  BookOpen,
  Clock,
  BarChart3,
  FileDown,
  Loader2,
} from 'lucide-react'

// ==========================================
// Props Interface
// ==========================================
interface StudentPanelProps {
  userId: string
  userName: string
  onLogout: () => void
  studentId: string // The Student record ID (not User ID)
}

// ==========================================
// Type definitions for API responses
// ==========================================
interface DashboardData {
  student: {
    id: string
    name: string
    email: string
    rollNo: string
    class: {
      id: string
      name: string
    }
  }
  overallStats: {
    totalClasses: number
    presentCount: number
    absentCount: number
    overallPercentage: number
    lowAttendanceWarning: boolean
  }
  subjectBreakdown: {
    subjectId: string
    subjectName: string
    totalClasses: number
    presentCount: number
    absentCount: number
    percentage: number
    warning: boolean
  }[]
  recentAttendance: {
    id: string
    date: string
    status: string
    subject: {
      id: string
      name: string
    }
  }[]
}

interface AttendanceRecord {
  id: string
  date: string
  status: string
  subject: {
    id: string
    name: string
  }
}

interface AttendanceData {
  student: {
    id: string
    name: string
    rollNo: string
    class: string
  }
  filters: {
    subjectId: string | null
    fromDate: string | null
    toDate: string | null
  }
  records: AttendanceRecord[]
  summary: {
    totalRecords: number
    presentCount: number
    absentCount: number
    overallPercentage: number
    lowAttendanceWarning: boolean
  }
  subjectBreakdown: {
    subjectId: string
    subjectName: string
    totalClasses: number
    presentCount: number
    absentCount: number
    percentage: number
    warning: boolean
  }[]
}

interface ChartData {
  student: {
    id: string
    name: string
  }
  monthlySummary: {
    month: string
    present: number
    absent: number
  }[]
  subjectWiseAttendance: {
    subject: string
    percentage: number
  }[]
  weeklyTrend: {
    week: string
    percentage: number
  }[]
}

// ==========================================
// Color palette for pie chart slices
// Using emerald/green tones with complementary colors
// ==========================================
const PIE_COLORS = [
  '#10b981', // emerald-500
  '#059669', // emerald-600
  '#34d399', // emerald-400
  '#6ee7b7', // emerald-300
  '#f59e0b', // amber-500
  '#ef4444', // red-500
  '#8b5cf6', // violet-500
  '#ec4899', // pink-500
  '#14b8a6', // teal-500
  '#f97316', // orange-500
]

// ==========================================
// Main Component
// ==========================================
export default function StudentPanel({
  userId,
  userName,
  onLogout,
  studentId,
}: StudentPanelProps) {
  const { toast } = useToast()

  // --- Dashboard state ---
  const [dashboard, setDashboard] = useState<DashboardData | null>(null)
  const [dashboardLoading, setDashboardLoading] = useState(true)

  // --- Attendance history state ---
  const [attendanceData, setAttendanceData] = useState<AttendanceData | null>(null)
  const [attendanceLoading, setAttendanceLoading] = useState(false)
  const [filterSubject, setFilterSubject] = useState<string>('all')
  const [filterFromDate, setFilterFromDate] = useState('')
  const [filterToDate, setFilterToDate] = useState('')

  // --- Charts state ---
  const [chartData, setChartData] = useState<ChartData | null>(null)
  const [chartLoading, setChartLoading] = useState(false)

  // --- Export state ---
  const [exportData, setExportData] = useState<AttendanceData | null>(null)
  const [exportLoading, setExportLoading] = useState(false)

  // ==========================================
  // Fetch dashboard data on mount
  // ==========================================
  const fetchDashboard = useCallback(async () => {
    setDashboardLoading(true)
    try {
      const res = await fetch(`/api/student/dashboard?studentId=${studentId}`)
      if (!res.ok) throw new Error('Failed to fetch dashboard')
      const data = await res.json()
      setDashboard(data)
    } catch {
      toast({
        title: 'Error',
        description: 'Failed to load dashboard data. Please try again.',
        variant: 'destructive',
      })
    } finally {
      setDashboardLoading(false)
    }
  }, [studentId, toast])

  useEffect(() => {
    fetchDashboard()
  }, [fetchDashboard])

  // ==========================================
  // Fetch attendance history with filters
  // ==========================================
  const fetchAttendance = useCallback(async () => {
    setAttendanceLoading(true)
    try {
      let url = `/api/student/attendance?studentId=${studentId}`
      if (filterSubject && filterSubject !== 'all') {
        url += `&subjectId=${filterSubject}`
      }
      if (filterFromDate) {
        url += `&fromDate=${filterFromDate}`
      }
      if (filterToDate) {
        url += `&toDate=${filterToDate}`
      }
      const res = await fetch(url)
      if (!res.ok) throw new Error('Failed to fetch attendance')
      const data = await res.json()
      setAttendanceData(data)
    } catch {
      toast({
        title: 'Error',
        description: 'Failed to load attendance history.',
        variant: 'destructive',
      })
    } finally {
      setAttendanceLoading(false)
    }
  }, [studentId, filterSubject, filterFromDate, filterToDate, toast])

  // ==========================================
  // Fetch chart data
  // ==========================================
  const fetchChartData = useCallback(async () => {
    setChartLoading(true)
    try {
      const res = await fetch(`/api/student/attendance-chart?studentId=${studentId}`)
      if (!res.ok) throw new Error('Failed to fetch chart data')
      const data = await res.json()
      setChartData(data)
    } catch {
      toast({
        title: 'Error',
        description: 'Failed to load chart data.',
        variant: 'destructive',
      })
    } finally {
      setChartLoading(false)
    }
  }, [studentId, toast])

  // ==========================================
  // Fetch export data
  // ==========================================
  const fetchExportData = useCallback(async () => {
    setExportLoading(true)
    try {
      const res = await fetch(`/api/student/attendance?studentId=${studentId}`)
      if (!res.ok) throw new Error('Failed to fetch export data')
      const data = await res.json()
      setExportData(data)
    } catch {
      toast({
        title: 'Error',
        description: 'Failed to load data for export.',
        variant: 'destructive',
      })
    } finally {
      setExportLoading(false)
    }
  }, [studentId, toast])

  // ==========================================
  // CSV Export handler
  // ==========================================
  const handleExportCSV = () => {
    if (!exportData || !exportData.records.length) {
      toast({
        title: 'No Data',
        description: 'No attendance records to export.',
        variant: 'destructive',
      })
      return
    }

    // Build CSV content
    const headers = 'Date,Subject,Status'
    const rows = exportData.records.map(
      (r) => `${r.date},${r.subject.name},${r.status}`
    )
    const csvContent = [headers, ...rows].join('\n')

    // Create a Blob and trigger download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `attendance_${userName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    toast({
      title: 'Export Successful',
      description: 'Your attendance data has been downloaded as CSV.',
    })
  }

  // ==========================================
  // Helper: Format date for display
  // ==========================================
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T00:00:00')
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })
  }

  // ==========================================
  // Loading skeleton component
  // ==========================================
  const LoadingSkeleton = () => (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      <span className="ml-3 text-muted-foreground">Loading...</span>
    </div>
  )

  // ==========================================
  // RENDER
  // ==========================================
  return (
    <div className="min-h-screen bg-gray-50">
      {/* ==================== HEADER ==================== */}
      <header className="sticky top-0 z-50 bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo / Title */}
            <div className="flex items-center gap-3">
              <div className="bg-emerald-600 text-white rounded-lg p-2">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">
                  Attendance Portal
                </h1>
                <p className="text-xs text-muted-foreground">Student Dashboard</p>
              </div>
            </div>

            {/* User Info & Logout */}
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 text-sm">
                <div className="bg-emerald-100 text-emerald-700 rounded-full p-1.5">
                  <User className="h-4 w-4" />
                </div>
                <span className="font-medium text-gray-700">{userName}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={onLogout}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* ==================== MAIN CONTENT ==================== */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs defaultValue="dashboard" className="space-y-6">
          {/* Tab Navigation */}
          <TabsList className="grid w-full grid-cols-4 h-12 bg-white border shadow-sm">
            <TabsTrigger
              value="dashboard"
              className="flex items-center gap-1.5 data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700"
            >
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger
              value="history"
              className="flex items-center gap-1.5 data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700"
            >
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">History</span>
            </TabsTrigger>
            <TabsTrigger
              value="charts"
              className="flex items-center gap-1.5 data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700"
            >
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Charts</span>
            </TabsTrigger>
            <TabsTrigger
              value="export"
              className="flex items-center gap-1.5 data-[state=active]:bg-emerald-50 data-[state=active]:text-emerald-700"
            >
              <FileDown className="h-4 w-4" />
              <span className="hidden sm:inline">Export</span>
            </TabsTrigger>
          </TabsList>

          {/* ==================== DASHBOARD TAB ==================== */}
          <TabsContent value="dashboard" className="space-y-6">
            {dashboardLoading ? (
              <LoadingSkeleton />
            ) : dashboard ? (
              <>
                {/* Low Attendance Warning Alert - very prominent */}
                {dashboard.overallStats.lowAttendanceWarning && (
                  <Alert className="border-red-300 bg-red-50 text-red-800 shadow-md">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    <AlertTitle className="text-red-800 font-bold text-lg">
                      Low Attendance Warning!
                    </AlertTitle>
                    <AlertDescription className="text-red-700">
                      Your attendance is below 75%. Please attend classes
                      regularly to avoid academic penalties.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Student Info + Overall Attendance Cards Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Student Info Card */}
                  <Card className="border-l-4 border-l-emerald-500">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base font-semibold text-gray-600 flex items-center gap-2">
                        <User className="h-4 w-4 text-emerald-600" />
                        Student Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Name</span>
                        <span className="font-semibold text-gray-900">
                          {dashboard.student.name}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Roll No</span>
                        <Badge variant="secondary" className="font-mono">
                          {dashboard.student.rollNo}
                        </Badge>
                      </div>
                      <Separator />
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Class</span>
                        <span className="font-medium text-gray-700">
                          {dashboard.student.class.name}
                        </span>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Overall Attendance Card */}
                  <Card
                    className={`border-l-4 ${
                      dashboard.overallStats.lowAttendanceWarning
                        ? 'border-l-red-500'
                        : 'border-l-emerald-500'
                    }`}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base font-semibold text-gray-600 flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-emerald-600" />
                        Overall Attendance
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="text-center py-4">
                      {/* Big percentage display */}
                      <div
                        className={`text-6xl font-black ${
                          dashboard.overallStats.lowAttendanceWarning
                            ? 'text-red-600'
                            : 'text-emerald-600'
                        }`}
                      >
                        {dashboard.overallStats.overallPercentage}%
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        attendance rate
                      </p>
                      {/* Progress bar */}
                      <div className="mt-4 px-4">
                        <Progress
                          value={dashboard.overallStats.overallPercentage}
                          className={`h-3 ${
                            dashboard.overallStats.lowAttendanceWarning
                              ? '[&>div]:bg-red-500'
                              : '[&>div]:bg-emerald-500'
                          }`}
                        />
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>0%</span>
                          <span>75% minimum</span>
                          <span>100%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* 3 Stat Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Total Classes */}
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="inline-flex items-center justify-center rounded-full bg-blue-100 p-3 mb-2">
                        <Clock className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="text-3xl font-bold text-gray-900">
                        {dashboard.overallStats.totalClasses}
                      </div>
                      <p className="text-sm text-muted-foreground">Total Classes</p>
                    </CardContent>
                  </Card>

                  {/* Present Count */}
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="inline-flex items-center justify-center rounded-full bg-emerald-100 p-3 mb-2">
                        <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                      </div>
                      <div className="text-3xl font-bold text-emerald-600">
                        {dashboard.overallStats.presentCount}
                      </div>
                      <p className="text-sm text-muted-foreground">Present</p>
                    </CardContent>
                  </Card>

                  {/* Absent Count */}
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="inline-flex items-center justify-center rounded-full bg-red-100 p-3 mb-2">
                        <XCircle className="h-5 w-5 text-red-600" />
                      </div>
                      <div className="text-3xl font-bold text-red-600">
                        {dashboard.overallStats.absentCount}
                      </div>
                      <p className="text-sm text-muted-foreground">Absent</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Per-Subject Breakdown Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-emerald-600" />
                      Subject-wise Attendance
                    </CardTitle>
                    <CardDescription>
                      Detailed breakdown of your attendance per subject
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {dashboard.subjectBreakdown.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No attendance records found.
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Subject</TableHead>
                              <TableHead className="text-center">
                                Total
                              </TableHead>
                              <TableHead className="text-center">
                                Present
                              </TableHead>
                              <TableHead className="text-center">
                                Absent
                              </TableHead>
                              <TableHead className="text-center">
                                Percentage
                              </TableHead>
                              <TableHead className="text-center">
                                Status
                              </TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {dashboard.subjectBreakdown.map((subject) => (
                              <TableRow
                                key={subject.subjectId}
                                className={
                                  subject.warning
                                    ? 'bg-red-50 hover:bg-red-100'
                                    : 'hover:bg-gray-50'
                                }
                              >
                                <TableCell className="font-medium">
                                  {subject.subjectName}
                                </TableCell>
                                <TableCell className="text-center">
                                  {subject.totalClasses}
                                </TableCell>
                                <TableCell className="text-center text-emerald-600 font-medium">
                                  {subject.presentCount}
                                </TableCell>
                                <TableCell className="text-center text-red-600 font-medium">
                                  {subject.absentCount}
                                </TableCell>
                                <TableCell className="text-center font-bold">
                                  {subject.percentage}%
                                </TableCell>
                                <TableCell className="text-center">
                                  {subject.warning ? (
                                    <Badge
                                      variant="destructive"
                                      className="bg-red-100 text-red-700 hover:bg-red-200 border border-red-200"
                                    >
                                      <AlertTriangle className="h-3 w-3 mr-1" />
                                      Low
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border border-emerald-200">
                                      <CheckCircle2 className="h-3 w-3 mr-1" />
                                      Good
                                    </Badge>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Recent Attendance */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-emerald-600" />
                      Recent Attendance
                    </CardTitle>
                    <CardDescription>Your last 10 attendance records</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {dashboard.recentAttendance.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No recent records.
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Subject</TableHead>
                              <TableHead className="text-center">
                                Status
                              </TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {dashboard.recentAttendance.map((record) => (
                              <TableRow key={record.id}>
                                <TableCell>
                                  {formatDate(record.date)}
                                </TableCell>
                                <TableCell>{record.subject.name}</TableCell>
                                <TableCell className="text-center">
                                  {record.status === 'PRESENT' ? (
                                    <Badge className="bg-emerald-100 text-emerald-700 border border-emerald-200">
                                      Present
                                    </Badge>
                                  ) : (
                                    <Badge
                                      variant="destructive"
                                      className="bg-red-100 text-red-700 hover:bg-red-200 border border-red-200"
                                    >
                                      Absent
                                    </Badge>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  Failed to load dashboard data. Please refresh.
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ==================== ATTENDANCE HISTORY TAB ==================== */}
          <TabsContent value="history" className="space-y-6">
            {/* Filter Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-emerald-600" />
                  Filter Attendance Records
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
                  {/* Subject Filter */}
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-gray-700">
                      Subject
                    </label>
                    <Select
                      value={filterSubject}
                      onValueChange={setFilterSubject}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="All Subjects" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Subjects</SelectItem>
                        {dashboard?.subjectBreakdown.map((s) => (
                          <SelectItem
                            key={s.subjectId}
                            value={s.subjectId}
                          >
                            {s.subjectName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* From Date */}
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-gray-700">
                      From Date
                    </label>
                    <Input
                      type="date"
                      value={filterFromDate}
                      onChange={(e) => setFilterFromDate(e.target.value)}
                    />
                  </div>

                  {/* To Date */}
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-gray-700">
                      To Date
                    </label>
                    <Input
                      type="date"
                      value={filterToDate}
                      onChange={(e) => setFilterToDate(e.target.value)}
                    />
                  </div>

                  {/* Apply Filter Button */}
                  <Button
                    onClick={fetchAttendance}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    <Calendar className="h-4 w-4 mr-1" />
                    Apply Filter
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Attendance Records Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-emerald-600" />
                  Attendance History
                </CardTitle>
                {attendanceData && (
                  <CardDescription>
                    Showing {attendanceData.records.length} records | Overall:{' '}
                    {attendanceData.summary.overallPercentage}% attendance
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent>
                {attendanceLoading ? (
                  <LoadingSkeleton />
                ) : attendanceData ? (
                  attendanceData.records.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No records found for the selected filters.
                    </p>
                  ) : (
                    <div className="max-h-96 overflow-y-auto">
                      <Table>
                        <TableHeader className="sticky top-0 bg-white">
                          <TableRow>
                            <TableHead>Date</TableHead>
                            <TableHead>Subject</TableHead>
                            <TableHead className="text-center">
                              Status
                            </TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {attendanceData.records.map((record) => (
                            <TableRow key={record.id}>
                              <TableCell>
                                {formatDate(record.date)}
                              </TableCell>
                              <TableCell>{record.subject.name}</TableCell>
                              <TableCell className="text-center">
                                {record.status === 'PRESENT' ? (
                                  <Badge className="bg-emerald-100 text-emerald-700 border border-emerald-200">
                                    Present
                                  </Badge>
                                ) : (
                                  <Badge
                                    variant="destructive"
                                    className="bg-red-100 text-red-700 hover:bg-red-200 border border-red-200"
                                  >
                                    Absent
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Calendar className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                    <p>Apply filters to view your attendance history.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ==================== CHARTS TAB ==================== */}
          <TabsContent
            value="charts"
            className="space-y-6"
            // Lazy-load chart data when tab is selected
            onFocus={() => {
              if (!chartData && !chartLoading) fetchChartData()
            }}
          >
            {/* Load chart data button (for initial load) */}
            {!chartData && !chartLoading && (
              <Card>
                <CardContent className="py-8 text-center">
                  <BarChart3 className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-muted-foreground mb-4">
                    Load your attendance charts to visualize trends
                  </p>
                  <Button
                    onClick={fetchChartData}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    <BarChart3 className="h-4 w-4 mr-1" />
                    Load Charts
                  </Button>
                </CardContent>
              </Card>
            )}

            {chartLoading && <LoadingSkeleton />}

            {chartData && !chartLoading && (
              <>
                {/* Monthly Attendance Bar Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-emerald-600" />
                      Monthly Attendance (Last 3 Months)
                    </CardTitle>
                    <CardDescription>
                      Present vs Absent count per month
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {chartData.monthlySummary.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No monthly data available.
                      </p>
                    ) : (
                      <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={chartData.monthlySummary}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar
                              dataKey="present"
                              name="Present"
                              fill="#10b981"
                              radius={[4, 4, 0, 0]}
                            />
                            <Bar
                              dataKey="absent"
                              name="Absent"
                              fill="#ef4444"
                              radius={[4, 4, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Subject-wise Pie Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-emerald-600" />
                      Subject-wise Attendance
                    </CardTitle>
                    <CardDescription>
                      Attendance percentage distribution across subjects
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {chartData.subjectWiseAttendance.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No subject data available.
                      </p>
                    ) : (
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={chartData.subjectWiseAttendance}
                              cx="50%"
                              cy="50%"
                              labelLine={true}
                              label={({ subject, percentage }) =>
                                `${subject}: ${percentage}%`
                              }
                              outerRadius={110}
                              fill="#8884d8"
                              dataKey="percentage"
                              nameKey="subject"
                            >
                              {chartData.subjectWiseAttendance.map(
                                (_, index) => (
                                  <Cell
                                    key={`cell-${index}`}
                                    fill={
                                      PIE_COLORS[
                                        index % PIE_COLORS.length
                                      ]
                                    }
                                  />
                                )
                              )}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Weekly Trend Line Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-emerald-600" />
                      Weekly Attendance Trend
                    </CardTitle>
                    <CardDescription>
                      Attendance percentage per week over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {chartData.weeklyTrend.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No weekly data available.
                      </p>
                    ) : (
                      <div className="h-72">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={chartData.weeklyTrend}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis
                              dataKey="week"
                              tick={{ fontSize: 11 }}
                            />
                            <YAxis domain={[0, 100]} />
                            <Tooltip
                              formatter={(value: number) => [
                                `${value}%`,
                                'Attendance',
                              ]}
                            />
                            <Legend />
                            <Line
                              type="monotone"
                              dataKey="percentage"
                              name="Attendance %"
                              stroke="#10b981"
                              strokeWidth={2}
                              dot={{ fill: '#10b981', r: 4 }}
                              activeDot={{ r: 6 }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>

          {/* ==================== EXPORT TAB ==================== */}
          <TabsContent value="export" className="space-y-6">
            {/* Export Action Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileDown className="h-5 w-5 text-emerald-600" />
                  Export Attendance Data
                </CardTitle>
                <CardDescription>
                  Download your complete attendance record as a CSV file
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Click the button below to fetch and download all your attendance
                  records in CSV format. The file will include Date, Subject, and
                  Status columns.
                </p>
                <div className="flex gap-3">
                  <Button
                    onClick={fetchExportData}
                    disabled={exportLoading}
                    variant="outline"
                    className="border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  >
                    {exportLoading ? (
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    ) : (
                      <BookOpen className="h-4 w-4 mr-1" />
                    )}
                    Load Data
                  </Button>
                  <Button
                    onClick={handleExportCSV}
                    disabled={!exportData || exportData.records.length === 0}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Export My Attendance
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Summary & Preview Table */}
            {exportLoading ? (
              <LoadingSkeleton />
            ) : exportData ? (
              <>
                {/* Summary Stats */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-gray-900">
                        {exportData.summary.totalRecords}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Total Records
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-emerald-600">
                        {exportData.summary.presentCount}
                      </div>
                      <p className="text-sm text-muted-foreground">Present</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div className="text-2xl font-bold text-red-600">
                        {exportData.summary.absentCount}
                      </div>
                      <p className="text-sm text-muted-foreground">Absent</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6 text-center">
                      <div
                        className={`text-2xl font-bold ${
                          exportData.summary.lowAttendanceWarning
                            ? 'text-red-600'
                            : 'text-emerald-600'
                        }`}
                      >
                        {exportData.summary.overallPercentage}%
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Attendance Rate
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Data Preview Table */}
                <Card>
                  <CardHeader>
                    <CardTitle>Data Preview</CardTitle>
                    <CardDescription>
                      Preview of your attendance data (CSV columns: Date,
                      Subject, Status)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {exportData.records.length === 0 ? (
                      <p className="text-center text-muted-foreground py-8">
                        No records to display.
                      </p>
                    ) : (
                      <div className="max-h-96 overflow-y-auto">
                        <Table>
                          <TableHeader className="sticky top-0 bg-white">
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Subject</TableHead>
                              <TableHead className="text-center">
                                Status
                              </TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {exportData.records.map((record) => (
                              <TableRow key={record.id}>
                                <TableCell>
                                  {formatDate(record.date)}
                                </TableCell>
                                <TableCell>{record.subject.name}</TableCell>
                                <TableCell className="text-center">
                                  {record.status === 'PRESENT' ? (
                                    <Badge className="bg-emerald-100 text-emerald-700 border border-emerald-200">
                                      Present
                                    </Badge>
                                  ) : (
                                    <Badge
                                      variant="destructive"
                                      className="bg-red-100 text-red-700 hover:bg-red-200 border border-red-200"
                                    >
                                      Absent
                                    </Badge>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  <FileDown className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                  <p>Click &quot;Load Data&quot; to fetch your attendance records for export.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
