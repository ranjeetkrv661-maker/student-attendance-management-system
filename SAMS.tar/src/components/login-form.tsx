'use client'

// Login Form Component
// Handles user authentication with email/password
// Supports Admin, Teacher, and Student login

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'
import { AuthUser } from '@/lib/auth-store'
import { GraduationCap, LogIn, AlertCircle } from 'lucide-react'

interface LoginFormProps {
  onLoginSuccess: (user: AuthUser) => void
}

export default function LoginForm({ onLoginSuccess }: LoginFormProps) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { toast } = useToast()

  // Handle login form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Login failed')
        toast({
          title: 'Login Failed',
          description: data.error || 'Invalid email or password',
          variant: 'destructive',
        })
        return
      }

      // Login successful
      toast({
        title: 'Welcome!',
        description: `Logged in as ${data.name} (${data.role})`,
      })
      onLoginSuccess(data)
    } catch {
      setError('Network error. Please try again.')
      toast({
        title: 'Error',
        description: 'Could not connect to server',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }

  // Quick-fill demo credentials
  const fillDemo = (role: string) => {
    if (role === 'admin') {
      setEmail('admin@college.edu')
      setPassword('admin123')
    } else if (role === 'teacher') {
      setEmail('rajesh@college.edu')
      setPassword('teacher123')
    } else {
      setEmail('rahul@student.edu')
      setPassword('student123')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-teal-50 p-4">
      <div className="w-full max-w-md">
        {/* Header / Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-100 mb-4">
            <GraduationCap className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Student Attendance System</h1>
          <p className="text-gray-500 mt-1">College of Computer Science, India</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-lg border-emerald-100">
          <CardHeader className="text-center">
            <CardTitle className="text-xl">Sign In</CardTitle>
            <CardDescription>Enter your credentials to access the system</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Error message */}
              {error && (
                <div className="flex items-center gap-2 p-3 rounded-md bg-red-50 border border-red-200 text-red-700 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Email field */}
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="border-emerald-200 focus:border-emerald-500"
                />
              </div>

              {/* Password field */}
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="border-emerald-200 focus:border-emerald-500"
                />
              </div>

              {/* Login button */}
              <Button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                disabled={loading}
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Signing in...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <LogIn className="w-4 h-4" />
                    Sign In
                  </span>
                )}
              </Button>
            </form>

            {/* Demo credentials section */}
            <div className="mt-6 pt-4 border-t border-gray-100">
              <p className="text-xs text-gray-500 text-center mb-3">Quick Login (Demo Credentials)</p>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => fillDemo('admin')}
                  className="px-3 py-2 text-xs font-medium rounded-md bg-gray-50 hover:bg-emerald-50 hover:text-emerald-700 border border-gray-200 hover:border-emerald-200 transition-colors"
                >
                  Admin
                </button>
                <button
                  onClick={() => fillDemo('teacher')}
                  className="px-3 py-2 text-xs font-medium rounded-md bg-gray-50 hover:bg-emerald-50 hover:text-emerald-700 border border-gray-200 hover:border-emerald-200 transition-colors"
                >
                  Teacher
                </button>
                <button
                  onClick={() => fillDemo('student')}
                  className="px-3 py-2 text-xs font-medium rounded-md bg-gray-50 hover:bg-emerald-50 hover:text-emerald-700 border border-gray-200 hover:border-emerald-200 transition-colors"
                >
                  Student
                </button>
              </div>
            </div>

            {/* Credentials info */}
            <div className="mt-4 p-3 rounded-md bg-emerald-50 border border-emerald-100">
              <p className="text-xs text-emerald-700 font-medium mb-1">Demo Credentials:</p>
              <div className="text-xs text-emerald-600 space-y-0.5">
                <p>Admin: admin@college.edu / admin123</p>
                <p>Teacher: rajesh@college.edu / teacher123</p>
                <p>Student: rahul@student.edu / student123</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-gray-400 mt-4">
          Student Attendance Management System &bull; Indian College Demo
        </p>
      </div>
    </div>
  )
}
