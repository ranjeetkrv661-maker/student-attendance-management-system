'use client'

import { useState, useEffect, useCallback } from 'react'
import { useToast } from '@/hooks/use-toast'
import {
  Users,
  GraduationCap,
  School,
  BookOpen,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  Download,
  Loader2,
  AlertCircle,
  LayoutDashboard,
  ClipboardList,
  UserCheck,
  FolderOpen,
  Tags,
  Link2,
  BarChart3,
  Search,
} from 'lucide-react'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'

// ============================================================
// Props Interface
// ============================================================
interface AdminPanelProps {
  userId: string
  userName: string
  onLogout: () => void
}

// ============================================================
// Type Definitions for API responses
// ============================================================
interface StudentData {
  id: string
  userId: string
  name: string
  email: string
  rollNo: string
  classId: string
  className: string
}

interface TeacherData {
  id: string
  userId: string
  name: string
  email: string
  assignments: { id: string; subjectId: string; subjectName: string; classId: string; className: string }[]
}

interface ClassData {
  id: string
  className: string
  studentCount: number
}

interface SubjectData {
  id: string
  subjectName: string
}

interface AssignmentData {
  id: number
  teacherId: string
  teacherName: string
  subjectId: string
  subjectName: string
  classId: string
  className: string
}

interface AttendanceRecord {
  id: string
  studentId: string
  studentName: string
  rollNo: string
  subjectId: string
  subjectName: string
  classId: string
  className: string
  date: string
  status: 'PRESENT' | 'ABSENT'
}

interface AttendanceSummary {
  totalClasses: number
  totalRecords: number
  studentSummary: {
    studentId: string
    studentName: string
    rollNo: string
    totalRecords: number
    presentCount: number
    absentCount: number
    attendancePercentage: number
  }[]
}

// ============================================================
// Main AdminPanel Component
// ============================================================
export default function AdminPanel({ userId, userName, onLogout }: AdminPanelProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState('dashboard')

  // ---- Dashboard state ----
  const [stats, setStats] = useState({ students: 0, teachers: 0, classes: 0, subjects: 0 })
  const [recentAttendance, setRecentAttendance] = useState<AttendanceRecord[]>([])
  const [dashboardLoading, setDashboardLoading] = useState(true)

  // ---- Students state ----
  const [students, setStudents] = useState<StudentData[]>([])
  const [studentsLoading, setStudentsLoading] = useState(false)
  const [studentDialogOpen, setStudentDialogOpen] = useState(false)
  const [editingStudent, setEditingStudent] = useState<StudentData | null>(null)
  const [studentForm, setStudentForm] = useState({ name: '', email: '', password: '', rollNo: '', classId: '' })
  const [savingStudent, setSavingStudent] = useState(false)

  // ---- Teachers state ----
  const [teachers, setTeachers] = useState<TeacherData[]>([])
  const [teachersLoading, setTeachersLoading] = useState(false)
  const [teacherDialogOpen, setTeacherDialogOpen] = useState(false)
  const [editingTeacher, setEditingTeacher] = useState<TeacherData | null>(null)
  const [teacherForm, setTeacherForm] = useState({ name: '', email: '', password: '' })
  const [savingTeacher, setSavingTeacher] = useState(false)

  // ---- Classes state ----
  const [classes, setClasses] = useState<ClassData[]>([])
  const [classesLoading, setClassesLoading] = useState(false)
  const [classDialogOpen, setClassDialogOpen] = useState(false)
  const [editingClass, setEditingClass] = useState<ClassData | null>(null)
  const [classForm, setClassForm] = useState({ className: '' })
  const [savingClass, setSavingClass] = useState(false)

  // ---- Subjects state ----
  const [subjects, setSubjects] = useState<SubjectData[]>([])
  const [subjectsLoading, setSubjectsLoading] = useState(false)
  const [subjectDialogOpen, setSubjectDialogOpen] = useState(false)
  const [editingSubject, setEditingSubject] = useState<SubjectData | null>(null)
  const [subjectForm, setSubjectForm] = useState({ subjectName: '' })
  const [savingSubject, setSavingSubject] = useState(false)

  // ---- Assign Subjects state ----
  const [assignments, setAssignments] = useState<AssignmentData[]>([])
  const [assignmentsLoading, setAssignmentsLoading] = useState(false)
  const [assignForm, setAssignForm] = useState({ teacherId: '', subjectId: '', classId: '' })
  const [savingAssignment, setSavingAssignment] = useState(false)

  // ---- Attendance Report state ----
  const [reportRecords, setReportRecords] = useState<AttendanceRecord[]>([])
  const [reportSummary, setReportSummary] = useState<AttendanceSummary | null>(null)
  const [reportLoading, setReportLoading] = useState(false)
  const [reportFilters, setReportFilters] = useState({ classId: '', subjectId: '', fromDate: '', toDate: '' })

  // ---- Delete confirmation state ----
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: string; id: string; extra?: Record<string, string> } | null>(null)
  const [deleting, setDeleting] = useState(false)

  // ============================================================
  // Data Fetching Functions
  // ============================================================

  /** Fetch all data needed for the dashboard overview */
  const fetchDashboard = useCallback(async () => {
    setDashboardLoading(true)
    try {
      const [studentsRes, teachersRes, classesRes, subjectsRes, attendanceRes] = await Promise.all([
        fetch('/api/admin/students'),
        fetch('/api/admin/teachers'),
        fetch('/api/admin/classes'),
        fetch('/api/admin/subjects'),
        fetch('/api/admin/attendance-report'),
      ])

      const studentsData = await studentsRes.json()
      const teachersData = await teachersRes.json()
      const classesData = await classesRes.json()
      const subjectsData = await subjectsRes.json()
      const attendanceData = await attendanceRes.json()

      setStats({
        students: Array.isArray(studentsData) ? studentsData.length : 0,
        teachers: Array.isArray(teachersData) ? teachersData.length : 0,
        classes: Array.isArray(classesData) ? classesData.length : 0,
        subjects: Array.isArray(subjectsData) ? subjectsData.length : 0,
      })

      // Show the 10 most recent attendance records
      if (attendanceData?.attendanceRecords) {
        setRecentAttendance(attendanceData.attendanceRecords.slice(0, 10))
      }
    } catch {
      toast({ title: 'Error', description: 'Failed to load dashboard data', variant: 'destructive' })
    } finally {
      setDashboardLoading(false)
    }
  }, [toast])

  const fetchStudents = useCallback(async () => {
    setStudentsLoading(true)
    try {
      const res = await fetch('/api/admin/students')
      const data = await res.json()
      setStudents(Array.isArray(data) ? data : [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load students', variant: 'destructive' })
    } finally {
      setStudentsLoading(false)
    }
  }, [toast])

  const fetchTeachers = useCallback(async () => {
    setTeachersLoading(true)
    try {
      const res = await fetch('/api/admin/teachers')
      const data = await res.json()
      setTeachers(Array.isArray(data) ? data : [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load teachers', variant: 'destructive' })
    } finally {
      setTeachersLoading(false)
    }
  }, [toast])

  const fetchClasses = useCallback(async () => {
    setClassesLoading(true)
    try {
      const res = await fetch('/api/admin/classes')
      const data = await res.json()
      setClasses(Array.isArray(data) ? data : [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load classes', variant: 'destructive' })
    } finally {
      setClassesLoading(false)
    }
  }, [toast])

  const fetchSubjects = useCallback(async () => {
    setSubjectsLoading(true)
    try {
      const res = await fetch('/api/admin/subjects')
      const data = await res.json()
      setSubjects(Array.isArray(data) ? data : [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load subjects', variant: 'destructive' })
    } finally {
      setSubjectsLoading(false)
    }
  }, [toast])

  const fetchAssignments = useCallback(async () => {
    setAssignmentsLoading(true)
    try {
      const res = await fetch('/api/admin/assign-subjects')
      const data = await res.json()
      setAssignments(Array.isArray(data) ? data : [])
    } catch {
      toast({ title: 'Error', description: 'Failed to load assignments', variant: 'destructive' })
    } finally {
      setAssignmentsLoading(false)
    }
  }, [toast])

  const fetchAttendanceReport = useCallback(async () => {
    setReportLoading(true)
    try {
      const params = new URLSearchParams()
      if (reportFilters.classId) params.set('classId', reportFilters.classId)
      if (reportFilters.subjectId) params.set('subjectId', reportFilters.subjectId)
      if (reportFilters.fromDate) params.set('fromDate', reportFilters.fromDate)
      if (reportFilters.toDate) params.set('toDate', reportFilters.toDate)

      const res = await fetch(`/api/admin/attendance-report?${params.toString()}`)
      const data = await res.json()
      setReportRecords(data.attendanceRecords || [])
      setReportSummary(data.summary || null)
    } catch {
      toast({ title: 'Error', description: 'Failed to load attendance report', variant: 'destructive' })
    } finally {
      setReportLoading(false)
    }
  }, [reportFilters, toast])

  // ============================================================
  // Load data on tab change
  // ============================================================
  useEffect(() => {
    fetchDashboard()
  }, [fetchDashboard])

  useEffect(() => {
    if (activeTab === 'students') fetchStudents()
    else if (activeTab === 'teachers') fetchTeachers()
    else if (activeTab === 'classes') fetchClasses()
    else if (activeTab === 'subjects') fetchSubjects()
    else if (activeTab === 'assign-subjects') {
      fetchAssignments()
      // Also fetch teachers, subjects, and classes for the dropdowns
      fetchTeachers()
      fetchSubjects()
      fetchClasses()
    }
    else if (activeTab === 'reports') {
      fetchAttendanceReport()
      // Fetch classes and subjects for filter dropdowns
      fetchClasses()
      fetchSubjects()
    }
  }, [activeTab, fetchStudents, fetchTeachers, fetchClasses, fetchSubjects, fetchAssignments, fetchAttendanceReport])

  // ============================================================
  // CRUD Handlers
  // ============================================================

  // --- Student CRUD ---
  const handleSaveStudent = async () => {
    setSavingStudent(true)
    try {
      if (editingStudent) {
        // Update existing student
        const res = await fetch(`/api/admin/students/${editingStudent.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: studentForm.name,
            email: studentForm.email,
            rollNo: studentForm.rollNo,
            classId: studentForm.classId,
          }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to update student')
        toast({ title: 'Success', description: 'Student updated successfully' })
      } else {
        // Create new student
        const res = await fetch('/api/admin/students', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(studentForm),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to create student')
        toast({ title: 'Success', description: 'Student created successfully' })
      }
      setStudentDialogOpen(false)
      setEditingStudent(null)
      setStudentForm({ name: '', email: '', password: '', rollNo: '', classId: '' })
      fetchStudents()
      fetchDashboard()
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Operation failed', variant: 'destructive' })
    } finally {
      setSavingStudent(false)
    }
  }

  const openStudentDialog = (student?: StudentData) => {
    if (student) {
      setEditingStudent(student)
      setStudentForm({ name: student.name, email: student.email, password: '', rollNo: student.rollNo, classId: student.classId })
    } else {
      setEditingStudent(null)
      setStudentForm({ name: '', email: '', password: '', rollNo: '', classId: '' })
    }
    setStudentDialogOpen(true)
  }

  // --- Teacher CRUD ---
  const handleSaveTeacher = async () => {
    setSavingTeacher(true)
    try {
      if (editingTeacher) {
        const res = await fetch(`/api/admin/teachers/${editingTeacher.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: teacherForm.name, email: teacherForm.email }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to update teacher')
        toast({ title: 'Success', description: 'Teacher updated successfully' })
      } else {
        const res = await fetch('/api/admin/teachers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(teacherForm),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to create teacher')
        toast({ title: 'Success', description: 'Teacher created successfully' })
      }
      setTeacherDialogOpen(false)
      setEditingTeacher(null)
      setTeacherForm({ name: '', email: '', password: '' })
      fetchTeachers()
      fetchDashboard()
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Operation failed', variant: 'destructive' })
    } finally {
      setSavingTeacher(false)
    }
  }

  const openTeacherDialog = (teacher?: TeacherData) => {
    if (teacher) {
      setEditingTeacher(teacher)
      setTeacherForm({ name: teacher.name, email: teacher.email, password: '' })
    } else {
      setEditingTeacher(null)
      setTeacherForm({ name: '', email: '', password: '' })
    }
    setTeacherDialogOpen(true)
  }

  // --- Class CRUD ---
  const handleSaveClass = async () => {
    setSavingClass(true)
    try {
      if (editingClass) {
        const res = await fetch(`/api/admin/classes/${editingClass.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ className: classForm.className }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to update class')
        toast({ title: 'Success', description: 'Class updated successfully' })
      } else {
        const res = await fetch('/api/admin/classes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ className: classForm.className }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to create class')
        toast({ title: 'Success', description: 'Class created successfully' })
      }
      setClassDialogOpen(false)
      setEditingClass(null)
      setClassForm({ className: '' })
      fetchClasses()
      fetchDashboard()
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Operation failed', variant: 'destructive' })
    } finally {
      setSavingClass(false)
    }
  }

  const openClassDialog = (cls?: ClassData) => {
    if (cls) {
      setEditingClass(cls)
      setClassForm({ className: cls.className })
    } else {
      setEditingClass(null)
      setClassForm({ className: '' })
    }
    setClassDialogOpen(true)
  }

  // --- Subject CRUD ---
  const handleSaveSubject = async () => {
    setSavingSubject(true)
    try {
      if (editingSubject) {
        const res = await fetch(`/api/admin/subjects/${editingSubject.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subjectName: subjectForm.subjectName }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to update subject')
        toast({ title: 'Success', description: 'Subject updated successfully' })
      } else {
        const res = await fetch('/api/admin/subjects', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subjectName: subjectForm.subjectName }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed to create subject')
        toast({ title: 'Success', description: 'Subject created successfully' })
      }
      setSubjectDialogOpen(false)
      setEditingSubject(null)
      setSubjectForm({ subjectName: '' })
      fetchSubjects()
      fetchDashboard()
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Operation failed', variant: 'destructive' })
    } finally {
      setSavingSubject(false)
    }
  }

  const openSubjectDialog = (subject?: SubjectData) => {
    if (subject) {
      setEditingSubject(subject)
      setSubjectForm({ subjectName: subject.subjectName })
    } else {
      setEditingSubject(null)
      setSubjectForm({ subjectName: '' })
    }
    setSubjectDialogOpen(true)
  }

  // --- Assign Subject ---
  const handleAssignSubject = async () => {
    setSavingAssignment(true)
    try {
      const res = await fetch('/api/admin/assign-subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(assignForm),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to assign subject')
      toast({ title: 'Success', description: 'Subject assigned successfully' })
      setAssignForm({ teacherId: '', subjectId: '', classId: '' })
      fetchAssignments()
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Operation failed', variant: 'destructive' })
    } finally {
      setSavingAssignment(false)
    }
  }

  // --- Delete Handler (generic) ---
  const handleDelete = async () => {
    if (!deleteConfirm) return
    setDeleting(true)
    try {
      let res: Response
      if (deleteConfirm.type === 'assignment') {
        // Assignment deletion uses body with teacherId, subjectId, classId
        res = await fetch('/api/admin/assign-subjects', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(deleteConfirm.extra),
        })
      } else {
        const endpointMap: Record<string, string> = {
          student: 'students',
          teacher: 'teachers',
          class: 'classes',
          subject: 'subjects',
        }
        const endpoint = endpointMap[deleteConfirm.type]
        res = await fetch(`/api/admin/${endpoint}/${deleteConfirm.id}`, { method: 'DELETE' })
      }

      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to delete')

      toast({ title: 'Success', description: 'Deleted successfully' })

      // Refresh relevant data
      if (deleteConfirm.type === 'student') { fetchStudents(); fetchDashboard() }
      else if (deleteConfirm.type === 'teacher') { fetchTeachers(); fetchDashboard() }
      else if (deleteConfirm.type === 'class') { fetchClasses(); fetchDashboard() }
      else if (deleteConfirm.type === 'subject') { fetchSubjects(); fetchDashboard() }
      else if (deleteConfirm.type === 'assignment') fetchAssignments()

      setDeleteConfirm(null)
    } catch (err) {
      toast({ title: 'Error', description: err instanceof Error ? err.message : 'Delete failed', variant: 'destructive' })
    } finally {
      setDeleting(false)
    }
  }

  // --- Export CSV ---
  const exportCSV = () => {
    if (reportRecords.length === 0) {
      toast({ title: 'No Data', description: 'No attendance records to export', variant: 'destructive' })
      return
    }

    const headers = ['Student Name', 'Roll No', 'Subject', 'Class', 'Date', 'Status']
    const rows = reportRecords.map(r => [r.studentName, r.rollNo, r.subjectName, r.className, r.date, r.status])

    const csvContent = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n')
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `attendance_report_${new Date().toISOString().split('T')[0]}.csv`
    link.click()
    URL.revokeObjectURL(url)
    toast({ title: 'Exported', description: 'CSV file downloaded successfully' })
  }

  // ============================================================
  // Helper: Loading Spinner
  // ============================================================
  const Spinner = ({ className = '' }: { className?: string }) => (
    <Loader2 className={`animate-spin ${className}`} />
  )

  // ============================================================
  // Helper: Empty State
  // ============================================================
  const EmptyState = ({ message }: { message: string }) => (
    <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
      <AlertCircle className="h-10 w-10 mb-2" />
      <p>{message}</p>
    </div>
  )

  // ============================================================
  // Tab definitions for the sidebar
  // ============================================================
  const tabItems = [
    { value: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { value: 'students', label: 'Students', icon: Users },
    { value: 'teachers', label: 'Teachers', icon: GraduationCap },
    { value: 'classes', label: 'Classes', icon: School },
    { value: 'subjects', label: 'Subjects', icon: BookOpen },
    { value: 'assign-subjects', label: 'Assign Subjects', icon: Link2 },
    { value: 'reports', label: 'Reports', icon: BarChart3 },
  ]

  // ============================================================
  // RENDER
  // ============================================================
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-30">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-600 flex items-center justify-center">
              <School className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900 leading-tight">AttendTrack</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Admin Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-sm">
              <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center">
                <span className="text-emerald-700 font-semibold text-xs">{userName.charAt(0).toUpperCase()}</span>
              </div>
              <span className="text-gray-700 font-medium">{userName}</span>
              <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 border-emerald-200">Admin</Badge>
            </div>
            <Button variant="outline" size="sm" onClick={onLogout} className="text-gray-600 hover:text-red-600">
              <LogOut className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Sidebar - Desktop */}
        <aside className="hidden lg:flex flex-col w-56 border-r bg-white shrink-0">
          <nav className="flex-1 p-3 space-y-1">
            {tabItems.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.value}
                  onClick={() => setActiveTab(tab.value)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === tab.value
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              )
            })}
          </nav>
        </aside>

        {/* Content Area */}
        <main className="flex-1 min-w-0">
          {/* Mobile Tab Bar */}
          <div className="lg:hidden border-b bg-white overflow-x-auto">
            <div className="flex gap-1 p-2 min-w-max">
              {tabItems.map((tab) => {
                const Icon = tab.icon
                return (
                  <button
                    key={tab.value}
                    onClick={() => setActiveTab(tab.value)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                      activeTab === tab.value
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {tab.label}
                  </button>
                )
              })}
            </div>
          </div>

          <div className="p-4 sm:p-6 max-w-[1400px] mx-auto">
            {/* ============================================================ */}
            {/* DASHBOARD TAB */}
            {/* ============================================================ */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                  <p className="text-muted-foreground text-sm">Overview of your attendance management system</p>
                </div>

                {/* Stat Cards */}
                {dashboardLoading ? (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    {[1, 2, 3, 4].map(i => (
                      <Card key={i} className="animate-pulse">
                        <CardContent className="p-6">
                          <div className="h-16 bg-gray-100 rounded" />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <StatCard icon={Users} label="Total Students" value={stats.students} color="emerald" />
                    <StatCard icon={GraduationCap} label="Total Teachers" value={stats.teachers} color="teal" />
                    <StatCard icon={School} label="Total Classes" value={stats.classes} color="cyan" />
                    <StatCard icon={BookOpen} label="Total Subjects" value={stats.subjects} color="green" />
                  </div>
                )}

                {/* Recent Attendance */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Recent Attendance Activity</CardTitle>
                    <CardDescription>Latest 10 attendance records across all classes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {dashboardLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading...</span>
                      </div>
                    ) : recentAttendance.length === 0 ? (
                      <EmptyState message="No attendance records yet" />
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Student</TableHead>
                              <TableHead>Subject</TableHead>
                              <TableHead>Class</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {recentAttendance.map((r) => (
                              <TableRow key={r.id}>
                                <TableCell className="font-medium">{r.studentName}</TableCell>
                                <TableCell>{r.subjectName}</TableCell>
                                <TableCell>{r.className}</TableCell>
                                <TableCell>{r.date}</TableCell>
                                <TableCell>
                                  <Badge variant={r.status === 'PRESENT' ? 'default' : 'destructive'}
                                    className={r.status === 'PRESENT' ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100' : ''}>
                                    {r.status}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* ============================================================ */}
            {/* STUDENTS TAB */}
            {/* ============================================================ */}
            {activeTab === 'students' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Students</h2>
                    <p className="text-muted-foreground text-sm">Manage student records</p>
                  </div>
                  <Button onClick={() => openStudentDialog()} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 mr-1" /> Add Student
                  </Button>
                </div>

                <Card>
                  <CardContent className="p-0">
                    {studentsLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading students...</span>
                      </div>
                    ) : students.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No students found. Add your first student!" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Roll No</TableHead>
                              <TableHead>Name</TableHead>
                              <TableHead className="hidden md:table-cell">Email</TableHead>
                              <TableHead>Class</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {students.map((s) => (
                              <TableRow key={s.id}>
                                <TableCell className="font-mono font-medium">{s.rollNo}</TableCell>
                                <TableCell className="font-medium">{s.name}</TableCell>
                                <TableCell className="hidden md:table-cell text-muted-foreground">{s.email}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="border-emerald-200 text-emerald-700 bg-emerald-50">
                                    {s.className}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <div className="flex items-center justify-end gap-1">
                                    <Button variant="ghost" size="sm" onClick={() => openStudentDialog(s)}>
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={() => setDeleteConfirm({ type: 'student', id: s.id })}>
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Student Dialog */}
                <Dialog open={studentDialogOpen} onOpenChange={setStudentDialogOpen}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{editingStudent ? 'Edit Student' : 'Add New Student'}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                      <div className="space-y-2">
                        <Label htmlFor="student-name">Name</Label>
                        <Input id="student-name" placeholder="Full name" value={studentForm.name}
                          onChange={e => setStudentForm(f => ({ ...f, name: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="student-email">Email</Label>
                        <Input id="student-email" type="email" placeholder="email@example.com" value={studentForm.email}
                          onChange={e => setStudentForm(f => ({ ...f, email: e.target.value }))} />
                      </div>
                      {!editingStudent && (
                        <div className="space-y-2">
                          <Label htmlFor="student-password">Password</Label>
                          <Input id="student-password" type="password" placeholder="Password" value={studentForm.password}
                            onChange={e => setStudentForm(f => ({ ...f, password: e.target.value }))} />
                        </div>
                      )}
                      <div className="space-y-2">
                        <Label htmlFor="student-rollno">Roll Number</Label>
                        <Input id="student-rollno" placeholder="e.g. BCA001" value={studentForm.rollNo}
                          onChange={e => setStudentForm(f => ({ ...f, rollNo: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="student-class">Class</Label>
                        <Select value={studentForm.classId} onValueChange={v => setStudentForm(f => ({ ...f, classId: v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classes.map(c => (
                              <SelectItem key={c.id} value={c.id}>{c.className}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setStudentDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleSaveStudent} disabled={savingStudent} className="bg-emerald-600 hover:bg-emerald-700">
                        {savingStudent && <Spinner className="h-4 w-4 mr-1" />}
                        {editingStudent ? 'Update' : 'Create'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}

            {/* ============================================================ */}
            {/* TEACHERS TAB */}
            {/* ============================================================ */}
            {activeTab === 'teachers' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Teachers</h2>
                    <p className="text-muted-foreground text-sm">Manage teacher records</p>
                  </div>
                  <Button onClick={() => openTeacherDialog()} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 mr-1" /> Add Teacher
                  </Button>
                </div>

                <Card>
                  <CardContent className="p-0">
                    {teachersLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading teachers...</span>
                      </div>
                    ) : teachers.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No teachers found. Add your first teacher!" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Name</TableHead>
                              <TableHead className="hidden md:table-cell">Email</TableHead>
                              <TableHead>Assigned Subjects</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {teachers.map((t) => (
                              <TableRow key={t.id}>
                                <TableCell className="font-medium">{t.name}</TableCell>
                                <TableCell className="hidden md:table-cell text-muted-foreground">{t.email}</TableCell>
                                <TableCell>
                                  <div className="flex flex-wrap gap-1">
                                    {t.assignments.length === 0 ? (
                                      <span className="text-xs text-muted-foreground">No assignments</span>
                                    ) : (
                                      t.assignments.map(a => (
                                        <Badge key={a.id} variant="secondary" className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs">
                                          {a.subjectName} ({a.className})
                                        </Badge>
                                      ))
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <div className="flex items-center justify-end gap-1">
                                    <Button variant="ghost" size="sm" onClick={() => openTeacherDialog(t)}>
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={() => setDeleteConfirm({ type: 'teacher', id: t.id })}>
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Teacher Dialog */}
                <Dialog open={teacherDialogOpen} onOpenChange={setTeacherDialogOpen}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{editingTeacher ? 'Edit Teacher' : 'Add New Teacher'}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                      <div className="space-y-2">
                        <Label htmlFor="teacher-name">Name</Label>
                        <Input id="teacher-name" placeholder="Full name" value={teacherForm.name}
                          onChange={e => setTeacherForm(f => ({ ...f, name: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="teacher-email">Email</Label>
                        <Input id="teacher-email" type="email" placeholder="email@example.com" value={teacherForm.email}
                          onChange={e => setTeacherForm(f => ({ ...f, email: e.target.value }))} />
                      </div>
                      {!editingTeacher && (
                        <div className="space-y-2">
                          <Label htmlFor="teacher-password">Password</Label>
                          <Input id="teacher-password" type="password" placeholder="Password" value={teacherForm.password}
                            onChange={e => setTeacherForm(f => ({ ...f, password: e.target.value }))} />
                        </div>
                      )}
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setTeacherDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleSaveTeacher} disabled={savingTeacher} className="bg-emerald-600 hover:bg-emerald-700">
                        {savingTeacher && <Spinner className="h-4 w-4 mr-1" />}
                        {editingTeacher ? 'Update' : 'Create'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}

            {/* ============================================================ */}
            {/* CLASSES TAB */}
            {/* ============================================================ */}
            {activeTab === 'classes' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Classes</h2>
                    <p className="text-muted-foreground text-sm">Manage class records</p>
                  </div>
                  <Button onClick={() => openClassDialog()} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 mr-1" /> Add Class
                  </Button>
                </div>

                <Card>
                  <CardContent className="p-0">
                    {classesLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading classes...</span>
                      </div>
                    ) : classes.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No classes found. Add your first class!" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Class Name</TableHead>
                              <TableHead>Student Count</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {classes.map((c) => (
                              <TableRow key={c.id}>
                                <TableCell className="font-medium">{c.className}</TableCell>
                                <TableCell>
                                  <Badge variant="secondary" className="bg-emerald-50 text-emerald-700">{c.studentCount} students</Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <div className="flex items-center justify-end gap-1">
                                    <Button variant="ghost" size="sm" onClick={() => openClassDialog(c)}>
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={() => setDeleteConfirm({ type: 'class', id: c.id })}>
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Class Dialog */}
                <Dialog open={classDialogOpen} onOpenChange={setClassDialogOpen}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{editingClass ? 'Edit Class' : 'Add New Class'}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                      <div className="space-y-2">
                        <Label htmlFor="class-name">Class Name</Label>
                        <Input id="class-name" placeholder="e.g. BCA 1st Year" value={classForm.className}
                          onChange={e => setClassForm({ className: e.target.value })} />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setClassDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleSaveClass} disabled={savingClass} className="bg-emerald-600 hover:bg-emerald-700">
                        {savingClass && <Spinner className="h-4 w-4 mr-1" />}
                        {editingClass ? 'Update' : 'Create'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}

            {/* ============================================================ */}
            {/* SUBJECTS TAB */}
            {/* ============================================================ */}
            {activeTab === 'subjects' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Subjects</h2>
                    <p className="text-muted-foreground text-sm">Manage subject records</p>
                  </div>
                  <Button onClick={() => openSubjectDialog()} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="h-4 w-4 mr-1" /> Add Subject
                  </Button>
                </div>

                <Card>
                  <CardContent className="p-0">
                    {subjectsLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading subjects...</span>
                      </div>
                    ) : subjects.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No subjects found. Add your first subject!" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Subject Name</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {subjects.map((s) => (
                              <TableRow key={s.id}>
                                <TableCell className="font-medium">{s.subjectName}</TableCell>
                                <TableCell className="text-right">
                                  <div className="flex items-center justify-end gap-1">
                                    <Button variant="ghost" size="sm" onClick={() => openSubjectDialog(s)}>
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={() => setDeleteConfirm({ type: 'subject', id: s.id })}>
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Subject Dialog */}
                <Dialog open={subjectDialogOpen} onOpenChange={setSubjectDialogOpen}>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>{editingSubject ? 'Edit Subject' : 'Add New Subject'}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                      <div className="space-y-2">
                        <Label htmlFor="subject-name">Subject Name</Label>
                        <Input id="subject-name" placeholder="e.g. Data Structures" value={subjectForm.subjectName}
                          onChange={e => setSubjectForm({ subjectName: e.target.value })} />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setSubjectDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleSaveSubject} disabled={savingSubject} className="bg-emerald-600 hover:bg-emerald-700">
                        {savingSubject && <Spinner className="h-4 w-4 mr-1" />}
                        {editingSubject ? 'Update' : 'Create'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}

            {/* ============================================================ */}
            {/* ASSIGN SUBJECTS TAB */}
            {/* ============================================================ */}
            {activeTab === 'assign-subjects' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Assign Subjects</h2>
                  <p className="text-muted-foreground text-sm">Assign subjects to teachers for specific classes</p>
                </div>

                {/* Assignment Form */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">New Assignment</CardTitle>
                    <CardDescription>Select a teacher, subject, and class to create an assignment</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Teacher</Label>
                        <Select value={assignForm.teacherId} onValueChange={v => setAssignForm(f => ({ ...f, teacherId: v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select teacher" />
                          </SelectTrigger>
                          <SelectContent>
                            {teachers.map(t => (
                              <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Subject</Label>
                        <Select value={assignForm.subjectId} onValueChange={v => setAssignForm(f => ({ ...f, subjectId: v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select subject" />
                          </SelectTrigger>
                          <SelectContent>
                            {subjects.map(s => (
                              <SelectItem key={s.id} value={s.id}>{s.subjectName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Class</Label>
                        <Select value={assignForm.classId} onValueChange={v => setAssignForm(f => ({ ...f, classId: v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classes.map(c => (
                              <SelectItem key={c.id} value={c.id}>{c.className}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button
                      onClick={handleAssignSubject}
                      disabled={savingAssignment || !assignForm.teacherId || !assignForm.subjectId || !assignForm.classId}
                      className="mt-4 bg-emerald-600 hover:bg-emerald-700"
                    >
                      {savingAssignment && <Spinner className="h-4 w-4 mr-1" />}
                      <Link2 className="h-4 w-4 mr-1" /> Assign
                    </Button>
                  </CardContent>
                </Card>

                {/* Assignments Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Current Assignments</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    {assignmentsLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading assignments...</span>
                      </div>
                    ) : assignments.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No assignments yet. Create one above!" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Teacher</TableHead>
                              <TableHead>Subject</TableHead>
                              <TableHead>Class</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {assignments.map((a) => (
                              <TableRow key={a.id}>
                                <TableCell className="font-medium">{a.teacherName}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="border-emerald-200 text-emerald-700 bg-emerald-50">
                                    {a.subjectName}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="secondary" className="bg-teal-50 text-teal-700">
                                    {a.className}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                    onClick={() => setDeleteConfirm({
                                      type: 'assignment',
                                      id: String(a.id),
                                      extra: { teacherId: a.teacherId, subjectId: a.subjectId, classId: a.classId }
                                    })}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}

            {/* ============================================================ */}
            {/* ATTENDANCE REPORTS TAB */}
            {/* ============================================================ */}
            {activeTab === 'reports' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">Attendance Reports</h2>
                    <p className="text-muted-foreground text-sm">View and export attendance data</p>
                  </div>
                  <Button onClick={exportCSV} variant="outline" className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
                    <Download className="h-4 w-4 mr-1" /> Export CSV
                  </Button>
                </div>

                {/* Filters */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Filters</CardTitle>
                    <CardDescription>Filter attendance records by class, subject, and date range</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label>Class</Label>
                        <Select value={reportFilters.classId} onValueChange={v => setReportFilters(f => ({ ...f, classId: v === '__all__' ? '' : v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Classes" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__all__">All Classes</SelectItem>
                            {classes.map(c => (
                              <SelectItem key={c.id} value={c.id}>{c.className}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Subject</Label>
                        <Select value={reportFilters.subjectId} onValueChange={v => setReportFilters(f => ({ ...f, subjectId: v === '__all__' ? '' : v }))}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="All Subjects" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="__all__">All Subjects</SelectItem>
                            {subjects.map(s => (
                              <SelectItem key={s.id} value={s.id}>{s.subjectName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>From Date</Label>
                        <Input type="date" value={reportFilters.fromDate}
                          onChange={e => setReportFilters(f => ({ ...f, fromDate: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>To Date</Label>
                        <Input type="date" value={reportFilters.toDate}
                          onChange={e => setReportFilters(f => ({ ...f, toDate: e.target.value }))} />
                      </div>
                    </div>
                    <Button onClick={fetchAttendanceReport} className="mt-4 bg-emerald-600 hover:bg-emerald-700">
                      <Search className="h-4 w-4 mr-1" /> Apply Filters
                    </Button>
                  </CardContent>
                </Card>

                {/* Summary Cards */}
                {reportSummary && (
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Total Sessions</p>
                        <p className="text-2xl font-bold text-emerald-700">{reportSummary.totalClasses}</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Total Records</p>
                        <p className="text-2xl font-bold text-teal-700">{reportSummary.totalRecords}</p>
                      </CardContent>
                    </Card>
                    <Card className="col-span-2 lg:col-span-1">
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-muted-foreground">Students Tracked</p>
                        <p className="text-2xl font-bold text-green-700">{reportSummary.studentSummary.length}</p>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Student Summary Table (if available) */}
                {reportSummary && reportSummary.studentSummary.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Student Attendance Summary</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Student</TableHead>
                              <TableHead>Roll No</TableHead>
                              <TableHead className="hidden sm:table-cell">Present</TableHead>
                              <TableHead className="hidden sm:table-cell">Absent</TableHead>
                              <TableHead>Attendance %</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {reportSummary.studentSummary.map((s) => (
                              <TableRow key={s.studentId}>
                                <TableCell className="font-medium">{s.studentName}</TableCell>
                                <TableCell className="font-mono">{s.rollNo}</TableCell>
                                <TableCell className="hidden sm:table-cell text-emerald-600">{s.presentCount}</TableCell>
                                <TableCell className="hidden sm:table-cell text-red-500">{s.absentCount}</TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <Progress value={s.attendancePercentage}
                                      className="h-2 w-16 [&>[data-slot=indicator]]:bg-emerald-500" />
                                    <span className={`text-sm font-medium ${s.attendancePercentage < 75 ? 'text-red-600' : 'text-emerald-700'}`}>
                                      {s.attendancePercentage}%
                                    </span>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Attendance Records Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Attendance Records</CardTitle>
                    <CardDescription>
                      {reportRecords.length > 0 ? `${reportRecords.length} records found` : 'No records to display'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    {reportLoading ? (
                      <div className="flex items-center justify-center py-12">
                        <Spinner className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-sm text-muted-foreground">Loading report...</span>
                      </div>
                    ) : reportRecords.length === 0 ? (
                      <div className="p-6">
                        <EmptyState message="No attendance records found for the selected filters" />
                      </div>
                    ) : (
                      <div className="overflow-x-auto max-h-96 overflow-y-auto">
                        <Table>
                          <TableHeader className="sticky top-0 bg-white z-10">
                            <TableRow>
                              <TableHead>Student</TableHead>
                              <TableHead>Roll No</TableHead>
                              <TableHead className="hidden md:table-cell">Subject</TableHead>
                              <TableHead className="hidden lg:table-cell">Class</TableHead>
                              <TableHead>Date</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {reportRecords.map((r) => (
                              <TableRow key={r.id}>
                                <TableCell className="font-medium">{r.studentName}</TableCell>
                                <TableCell className="font-mono">{r.rollNo}</TableCell>
                                <TableCell className="hidden md:table-cell">{r.subjectName}</TableCell>
                                <TableCell className="hidden lg:table-cell">{r.className}</TableCell>
                                <TableCell>{r.date}</TableCell>
                                <TableCell>
                                  <Badge variant={r.status === 'PRESENT' ? 'default' : 'destructive'}
                                    className={r.status === 'PRESENT' ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100' : ''}>
                                    {r.status}
                                  </Badge>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* ============================================================ */}
      {/* Delete Confirmation Dialog */}
      {/* ============================================================ */}
      <Dialog open={!!deleteConfirm} onOpenChange={(open) => { if (!open) setDeleteConfirm(null) }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Are you sure you want to delete this {deleteConfirm?.type}? This action cannot be undone.
              {deleteConfirm?.type === 'class' && ' All students in this class and related attendance records will also be deleted.'}
              {deleteConfirm?.type === 'teacher' && ' All subject assignments and related attendance records will also be deleted.'}
              {deleteConfirm?.type === 'subject' && ' All related attendance records and teacher assignments will also be deleted.'}
              {deleteConfirm?.type === 'student' && ' All attendance records for this student will also be deleted.'}
            </AlertDescription>
          </Alert>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting && <Spinner className="h-4 w-4 mr-1" />}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================================
// StatCard Sub-Component
// ============================================================
function StatCard({ icon: Icon, label, value, color }: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  color: 'emerald' | 'teal' | 'cyan' | 'green'
}) {
  const colorMap = {
    emerald: 'bg-emerald-50 text-emerald-600',
    teal: 'bg-teal-50 text-teal-600',
    cyan: 'bg-cyan-50 text-cyan-600',
    green: 'bg-green-50 text-green-600',
  }
  const iconBgMap = {
    emerald: 'bg-emerald-100',
    teal: 'bg-teal-100',
    cyan: 'bg-cyan-100',
    green: 'bg-green-100',
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${iconBgMap[color]}`}>
            <Icon className={`h-6 w-6 ${colorMap[color].split(' ')[1]}`} />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
