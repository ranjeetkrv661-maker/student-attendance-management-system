'use client'

// Main Page - Student Attendance Management System
// Handles routing between Login, Admin Panel, Teacher Panel, and Student Panel
// Uses Zustand for auth state management

import { useEffect, useState, useCallback } from 'react'
import { useAuthStore, AuthUser } from '@/lib/auth-store'
import LoginForm from '@/components/login-form'
import AdminPanel from '@/components/admin-panel'
import TeacherPanel from '@/components/teacher-panel'
import StudentPanel from '@/components/student-panel'

export default function Home() {
  const { user, isLoggedIn, login, logout } = useAuthStore()
  const [profileData, setProfileData] = useState<{
    studentId?: string
    teacherId?: string
  }>({})
  const [profileLoading, setProfileLoading] = useState(false)
  const [seeded, setSeeded] = useState(false)
  const [seeding, setSeeding] = useState(false)

  // Seed the database on first load
  useEffect(() => {
    if (!seeded && !seeding) {
      setSeeding(true)
      fetch('/api/seed', { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          console.log('Database seeded:', data.message || 'OK')
          setSeeded(false)
          setSeeded(true)
        })
        .catch(err => {
          console.error('Seed error:', err)
          setSeeding(false)
          setSeeded(true) // Don't block on error
        })
    }
  }, [seeded, seeding])

  // Fetch role-specific profile data when user logs in
  const fetchProfile = useCallback(async (userId: string) => {
    setProfileLoading(true)
    try {
      const res = await fetch(`/api/auth/me?userId=${userId}`)
      if (res.ok) {
        const data = await res.json()
        setProfileData({
          studentId: data.student?.id,
          teacherId: data.teacher?.id,
        })
      }
    } catch (err) {
      console.error('Profile fetch error:', err)
    } finally {
      setProfileLoading(false)
    }
  }, [])

  // When user logs in, fetch their profile
  useEffect(() => {
    if (isLoggedIn && user?.id) {
      fetchProfile(user.id)
    }
  }, [isLoggedIn, user?.id, fetchProfile])

  // Handle successful login
  const handleLoginSuccess = (userData: AuthUser) => {
    login(userData)
  }

  // Handle logout
  const handleLogout = () => {
    logout()
    setProfileData({})
  }

  // Show login form if not authenticated
  if (!isLoggedIn || !user) {
    return <LoginForm onLoginSuccess={handleLoginSuccess} />
  }

  // Show loading while fetching profile
  if (profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-white to-teal-50">
        <div className="text-center">
          <svg className="animate-spin h-8 w-8 text-emerald-600 mx-auto mb-4" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  // Route to appropriate panel based on role
  switch (user.role) {
    case 'ADMIN':
      return (
        <AdminPanel
          userId={user.id}
          userName={user.name}
          onLogout={handleLogout}
        />
      )
    case 'TEACHER':
      return (
        <TeacherPanel
          userId={profileData.teacherId || user.id}
          userName={user.name}
          onLogout={handleLogout}
        />
      )
    case 'STUDENT':
      return (
        <StudentPanel
          userId={user.id}
          userName={user.name}
          studentId={profileData.studentId || ''}
          onLogout={handleLogout}
        />
      )
    default:
      return <LoginForm onLoginSuccess={handleLoginSuccess} />
  }
}
