import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/attendance/check?classId=xxx&subjectId=xxx&date=YYYY-MM-DD
// Checks if attendance has already been marked for a specific class/subject/date combination
// Returns { exists: boolean, records: [...] } so the frontend can pre-fill if needed

export async function GET(request: NextRequest) {
  try {
    const classId = request.nextUrl.searchParams.get('classId')
    const subjectId = request.nextUrl.searchParams.get('subjectId')
    const date = request.nextUrl.searchParams.get('date')

    // --- Validate required query params ---
    if (!classId || !subjectId || !date) {
      return NextResponse.json(
        { error: 'Missing required query params: classId, subjectId, date' },
        { status: 400 }
      )
    }

    // Validate date format
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/
    if (!dateRegex.test(date)) {
      return NextResponse.json(
        { error: 'Invalid date format. Use YYYY-MM-DD' },
        { status: 400 }
      )
    }

    // Find attendance records matching classId + subjectId + date
    const records = await db.attendance.findMany({
      where: {
        classId,
        subjectId,
        date,
      },
      include: {
        student: {
          include: {
            user: {
              select: { name: true },
            },
          },
        },
      },
    })

    // If records found, attendance has already been marked
    const exists = records.length > 0

    // Shape the records for easy frontend consumption
    const shapedRecords = records.map((r) => ({
      id: r.id,
      studentId: r.studentId,
      studentName: r.student.user.name,
      rollNo: r.student.rollNo,
      status: r.status,
    }))

    return NextResponse.json({ exists, records: shapedRecords })
  } catch (error) {
    console.error('Error checking attendance:', error)
    return NextResponse.json(
      { error: 'Failed to check attendance' },
      { status: 500 }
    )
  }
}
