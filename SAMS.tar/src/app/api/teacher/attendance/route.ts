import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// POST /api/teacher/attendance
// Mark attendance for a class/subject on a specific date
// Body: { teacherId, classId, subjectId, date, records: [{ studentId, status: "PRESENT"|"ABSENT" }] }
// Uses upsert on the unique constraint (studentId, classId, subjectId, date) to handle re-marking

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { teacherId, classId, subjectId, date, records } = body

    // --- Validate required fields ---
    if (!teacherId || !classId || !subjectId || !date || !records || !Array.isArray(records)) {
      return NextResponse.json(
        { error: 'Missing required fields: teacherId, classId, subjectId, date, records' },
        { status: 400 }
      )
    }

    // Validate date format (YYYY-MM-DD)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/
    if (!dateRegex.test(date)) {
      return NextResponse.json(
        { error: 'Invalid date format. Use YYYY-MM-DD' },
        { status: 400 }
      )
    }

    // Validate each record has studentId and status
    for (const record of records) {
      if (!record.studentId || !record.status) {
        return NextResponse.json(
          { error: 'Each record must have studentId and status' },
          { status: 400 }
        )
      }
      if (record.status !== 'PRESENT' && record.status !== 'ABSENT') {
        return NextResponse.json(
          { error: `Invalid status "${record.status}". Must be PRESENT or ABSENT` },
          { status: 400 }
        )
      }
    }

    // Verify that the teacher is assigned to this class+subject combination
    const assignment = await db.teacherSubject.findUnique({
      where: {
        teacherId_subjectId_classId: {
          teacherId,
          subjectId,
          classId,
        },
      },
    })

    if (!assignment) {
      return NextResponse.json(
        { error: 'Teacher is not assigned to this subject for this class' },
        { status: 403 }
      )
    }

    // Upsert attendance records — creates new or updates existing
    const upsertPromises = records.map((record: { studentId: string; status: string }) =>
      db.attendance.upsert({
        where: {
          studentId_classId_subjectId_date: {
            studentId: record.studentId,
            classId,
            subjectId,
            date,
          },
        },
        update: {
          status: record.status,
        },
        create: {
          studentId: record.studentId,
          classId,
          subjectId,
          date,
          status: record.status,
        },
      })
    )

    const savedRecords = await Promise.all(upsertPromises)

    return NextResponse.json({
      message: 'Attendance marked successfully',
      count: savedRecords.length,
      date,
      classId,
      subjectId,
    })
  } catch (error) {
    console.error('Error marking attendance:', error)
    return NextResponse.json(
      { error: 'Failed to mark attendance' },
      { status: 500 }
    )
  }
}
