import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/subjects?teacherId=xxx&classId=xxx
// Returns all subjects assigned to a teacher for a specific class

export async function GET(request: NextRequest) {
  try {
    const teacherId = request.nextUrl.searchParams.get('teacherId')
    const classId = request.nextUrl.searchParams.get('classId')

    // --- Validate required params ---
    if (!teacherId) {
      return NextResponse.json(
        { error: 'teacherId query parameter is required' },
        { status: 400 }
      )
    }
    if (!classId) {
      return NextResponse.json(
        { error: 'classId query parameter is required' },
        { status: 400 }
      )
    }

    // Find all TeacherSubject entries matching teacherId + classId
    const teacherSubjects = await db.teacherSubject.findMany({
      where: {
        teacherId,
        classId,
      },
      include: {
        subject: true,
      },
    })

    // Extract subject details
    const subjects = teacherSubjects.map((ts) => ({
      id: ts.subject.id,
      subjectName: ts.subject.subjectName,
      assignmentId: ts.id, // useful if frontend needs to reference the assignment
    }))

    return NextResponse.json({ subjects })
  } catch (error) {
    console.error('Error fetching teacher subjects:', error)
    return NextResponse.json(
      { error: 'Failed to fetch subjects' },
      { status: 500 }
    )
  }
}
