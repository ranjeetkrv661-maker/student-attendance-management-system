import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/history?teacherId=xxx&classId=xxx&subjectId=xxx&fromDate=YYYY-MM-DD&toDate=YYYY-MM-DD
// Returns attendance history for a teacher, grouped by date with summary per date
// classId, subjectId, fromDate, toDate are optional filters

export async function GET(request: NextRequest) {
  try {
    const teacherId = request.nextUrl.searchParams.get('teacherId')
    const classId = request.nextUrl.searchParams.get('classId')
    const subjectId = request.nextUrl.searchParams.get('subjectId')
    const fromDate = request.nextUrl.searchParams.get('fromDate')
    const toDate = request.nextUrl.searchParams.get('toDate')

    // --- Validate required params ---
    if (!teacherId) {
      return NextResponse.json(
        { error: 'teacherId query parameter is required' },
        { status: 400 }
      )
    }

    // Validate date formats if provided
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/
    if (fromDate && !dateRegex.test(fromDate)) {
      return NextResponse.json(
        { error: 'Invalid fromDate format. Use YYYY-MM-DD' },
        { status: 400 }
      )
    }
    if (toDate && !dateRegex.test(toDate)) {
      return NextResponse.json(
        { error: 'Invalid toDate format. Use YYYY-MM-DD' },
        { status: 400 }
      )
    }

    // Step 1: Get all class+subject assignments for this teacher
    const teacherSubjects = await db.teacherSubject.findMany({
      where: { teacherId },
      select: { classId: true, subjectId: true },
    })

    if (teacherSubjects.length === 0) {
      return NextResponse.json({ history: [] })
    }

    // Build filter conditions for attendance records
    // Only include attendance from classes/subjects the teacher is assigned to
    const assignedCombinations = teacherSubjects.map((ts) => ({
      classId: ts.classId,
      subjectId: ts.subjectId,
    }))

    // Build the where clause
    // Using Record<string, unknown> for dynamic Prisma where clause construction
    const whereClause: Record<string, unknown> = {
      OR: assignedCombinations.map((combo) => ({
        classId: combo.classId,
        subjectId: combo.subjectId,
      })),
    }

    // Apply optional filters
    if (classId) {
      // If classId filter is provided, only keep combos matching that classId
      whereClause.OR = whereClause.OR.filter(
        (combo: { classId: string }) => combo.classId === classId
      )
    }
    if (subjectId) {
      whereClause.OR = whereClause.OR.filter(
        (combo: { subjectId: string }) => combo.subjectId === subjectId
      )
    }
    if (fromDate) {
      whereClause.date = { gte: fromDate }
    }
    if (toDate) {
      // Combine with existing date filter if fromDate is also set
      if (whereClause.date) {
        whereClause.date = { gte: fromDate, lte: toDate }
      } else {
        whereClause.date = { lte: toDate }
      }
    }

    // If after filtering no combinations remain, return empty
    if (whereClause.OR.length === 0) {
      return NextResponse.json({ history: [] })
    }

    // Step 2: Fetch attendance records matching the filters
    const attendanceRecords = await db.attendance.findMany({
      where: whereClause,
      include: {
        student: {
          include: {
            user: { select: { name: true } },
          },
        },
        class: { select: { className: true } },
        subject: { select: { subjectName: true } },
      },
      orderBy: { date: 'desc' },
    })

    // Step 3: Group records by date and build summary
    const groupedByDate = new Map<string, {
      date: string
      className: string
      subjectName: string
      records: { studentId: string; studentName: string; rollNo: string; status: string }[]
      totalStudents: number
      presentCount: number
      absentCount: number
    }>()

    for (const record of attendanceRecords) {
      // Create a unique key per date+class+subject combo
      const key = `${record.date}_${record.classId}_${record.subjectId}`

      if (groupedByDate.has(key)) {
        const group = groupedByDate.get(key)!
        group.records.push({
          studentId: record.studentId,
          studentName: record.student.user.name,
          rollNo: record.student.rollNo,
          status: record.status,
        })
        if (record.status === 'PRESENT') {
          group.presentCount++
        } else {
          group.absentCount++
        }
        group.totalStudents++
      } else {
        groupedByDate.set(key, {
          date: record.date,
          className: record.class.className,
          subjectName: record.subject.subjectName,
          records: [{
            studentId: record.studentId,
            studentName: record.student.user.name,
            rollNo: record.student.rollNo,
            status: record.status,
          }],
          totalStudents: 1,
          presentCount: record.status === 'PRESENT' ? 1 : 0,
          absentCount: record.status === 'ABSENT' ? 1 : 0,
        })
      }
    }

    // Convert to array and sort by date descending
    const history = Array.from(groupedByDate.values()).sort(
      (a, b) => b.date.localeCompare(a.date)
    )

    return NextResponse.json({ history, totalDays: history.length })
  } catch (error) {
    console.error('Error fetching attendance history:', error)
    return NextResponse.json(
      { error: 'Failed to fetch attendance history' },
      { status: 500 }
    )
  }
}
