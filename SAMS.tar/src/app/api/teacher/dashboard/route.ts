import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/dashboard?teacherId=xxx
// Returns a dashboard summary for the teacher:
//   - totalClasses: number of distinct classes assigned
//   - totalStudents: number of distinct students across all assigned classes
//   - recentAttendance: last 5 attendance records the teacher submitted

export async function GET(request: NextRequest) {
  try {
    const teacherId = request.nextUrl.searchParams.get('teacherId')

    if (!teacherId) {
      return NextResponse.json(
        { error: 'teacherId query parameter is required' },
        { status: 400 }
      )
    }

    // Step 1: Get all class+subject assignments for this teacher
    const teacherSubjects = await db.teacherSubject.findMany({
      where: { teacherId },
      include: {
        class: {
          include: {
            students: {
              include: {
                user: { select: { name: true } },
              },
            },
          },
        },
        subject: true,
      },
    })

    // Step 2: Calculate total distinct classes
    const uniqueClassIds = new Set(teacherSubjects.map((ts) => ts.classId))
    const totalClasses = uniqueClassIds.size

    // Step 3: Calculate total distinct students across all assigned classes
    const uniqueStudentIds = new Set<string>()
    for (const ts of teacherSubjects) {
      for (const student of ts.class.students) {
        uniqueStudentIds.add(student.id)
      }
    }
    const totalStudents = uniqueStudentIds.size

    // Step 4: Get recent attendance records (last 5) for this teacher's classes/subjects
    const assignedCombinations = teacherSubjects.map((ts) => ({
      classId: ts.classId,
      subjectId: ts.subjectId,
    }))

    let recentAttendance: {
      id: string
      date: string
      status: string
      studentName: string
      rollNo: string
      className: string
      subjectName: string
    }[] = []

    if (assignedCombinations.length > 0) {
      const attendanceRecords = await db.attendance.findMany({
        where: {
          OR: assignedCombinations.map((combo) => ({
            classId: combo.classId,
            subjectId: combo.subjectId,
          })),
        },
        include: {
          student: {
            include: {
              user: { select: { name: true } },
            },
          },
          class: { select: { className: true } },
          subject: { select: { subjectName: true } },
        },
        orderBy: [
          { date: 'desc' },
          { student: { rollNo: 'asc' } },
        ],
        take: 5,
      })

      recentAttendance = attendanceRecords.map((r) => ({
        id: r.id,
        date: r.date,
        status: r.status,
        studentName: r.student.user.name,
        rollNo: r.student.rollNo,
        className: r.class.className,
        subjectName: r.subject.subjectName,
      }))
    }

    // Step 5: Build class list with student counts for the dashboard
    const classList = Array.from(uniqueClassIds).map((classId) => {
      const ts = teacherSubjects.find((t) => t.classId === classId)!
      return {
        id: classId,
        className: ts.class.className,
        studentCount: ts.class.students.length,
        subjects: teacherSubjects
          .filter((t) => t.classId === classId)
          .map((t) => ({ id: t.subject.id, subjectName: t.subject.subjectName })),
      }
    })

    return NextResponse.json({
      totalClasses,
      totalStudents,
      recentAttendance,
      classList,
    })
  } catch (error) {
    console.error('Error fetching teacher dashboard:', error)
    return NextResponse.json(
      { error: 'Failed to fetch dashboard data' },
      { status: 500 }
    )
  }
}
