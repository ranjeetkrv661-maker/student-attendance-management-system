import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/classes?teacherId=xxx
// Returns all classes assigned to a teacher (through TeacherSubject), including subject names

export async function GET(request: NextRequest) {
  try {
    const teacherId = request.nextUrl.searchParams.get('teacherId')

    if (!teacherId) {
      return NextResponse.json(
        { error: 'teacherId query parameter is required' },
        { status: 400 }
      )
    }

    // Find all TeacherSubject entries for this teacher
    // This gives us the classes and subjects the teacher is assigned to
    const teacherSubjects = await db.teacherSubject.findMany({
      where: { teacherId },
      include: {
        class: true,
        subject: true,
      },
    })

    // Group by class — a teacher may teach multiple subjects in the same class
    const classMap = new Map<string, { id: string; className: string; subjects: { id: string; subjectName: string }[] }>()

    for (const ts of teacherSubjects) {
      const existing = classMap.get(ts.classId)
      if (existing) {
        // Add subject to existing class entry
        existing.subjects.push({ id: ts.subject.id, subjectName: ts.subject.subjectName })
      } else {
        // Create new class entry
        classMap.set(ts.classId, {
          id: ts.class.id,
          className: ts.class.className,
          subjects: [{ id: ts.subject.id, subjectName: ts.subject.subjectName }],
        })
      }
    }

    // Convert map to array
    const classes = Array.from(classMap.values())

    return NextResponse.json({ classes })
  } catch (error) {
    console.error('Error fetching teacher classes:', error)
    return NextResponse.json(
      { error: 'Failed to fetch classes' },
      { status: 500 }
    )
  }
}
