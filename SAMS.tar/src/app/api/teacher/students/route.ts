import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/teacher/students?classId=xxx
// Returns all students in a specific class with their user info (name, rollNo)

export async function GET(request: NextRequest) {
  try {
    const classId = request.nextUrl.searchParams.get('classId')

    if (!classId) {
      return NextResponse.json(
        { error: 'classId query parameter is required' },
        { status: 400 }
      )
    }

    // Verify the class exists
    const classExists = await db.class.findUnique({
      where: { id: classId },
    })

    if (!classExists) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Fetch all students in this class, including their user info
    const students = await db.student.findMany({
      where: { classId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: { rollNo: 'asc' },
    })

    // Shape the response to include studentId, rollNo, and user name
    const result = students.map((s) => ({
      id: s.id,
      rollNo: s.rollNo,
      name: s.user.name,
      email: s.user.email,
    }))

    return NextResponse.json({ students: result, className: classExists.className })
  } catch (error) {
    console.error('Error fetching students:', error)
    return NextResponse.json(
      { error: 'Failed to fetch students' },
      { status: 500 }
    )
  }
}
