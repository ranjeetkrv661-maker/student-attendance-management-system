import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/student/attendance-chart?studentId=xxx
// Returns attendance data formatted for charts:
//   - Monthly attendance summary (last 3 months)
//   - Subject-wise attendance percentages
//   - Weekly trend (attendance % per week)

export async function GET(request: NextRequest) {
  try {
    const studentId = request.nextUrl.searchParams.get('studentId')

    if (!studentId) {
      return NextResponse.json(
        { error: 'studentId query parameter is required' },
        { status: 400 }
      )
    }

    // Verify student exists
    const student = await db.student.findUnique({
      where: { id: studentId },
      include: { user: true },
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // Fetch all attendance records for this student
    const allAttendance = await db.attendance.findMany({
      where: { studentId },
      include: {
        subject: {
          select: { id: true, subjectName: true },
        },
      },
      orderBy: { date: 'asc' },
    })

    // ==========================================
    // 1. Monthly attendance summary (last 3 months)
    // ==========================================
    // Determine the 3 most recent months from the data
    const monthSet = new Set<string>()
    for (const record of allAttendance) {
      // Extract "YYYY-MM" from the date string
      const month = record.date.substring(0, 7)
      monthSet.add(month)
    }

    // Sort months descending and take the last 3
    const sortedMonths = Array.from(monthSet).sort().reverse().slice(0, 3)
    // Re-sort ascending for chart display (oldest first)
    sortedMonths.reverse()

    const monthlySummary = sortedMonths.map((month) => {
      const monthRecords = allAttendance.filter(
        (r) => r.date.substring(0, 7) === month
      )
      const present = monthRecords.filter(
        (r) => r.status === 'PRESENT'
      ).length
      const absent = monthRecords.filter((r) => r.status === 'ABSENT').length

      // Format month label: "2024-01" -> "Jan 2024"
      const [year, mon] = month.split('-')
      const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
      ]
      const label = `${monthNames[parseInt(mon, 10) - 1]} ${year}`

      return { month: label, present, absent }
    })

    // ==========================================
    // 2. Subject-wise attendance
    // ==========================================
    const subjectMap = new Map<
      string,
      { subjectName: string; total: number; present: number }
    >()

    for (const record of allAttendance) {
      const existing = subjectMap.get(record.subjectId)
      if (existing) {
        existing.total += 1
        if (record.status === 'PRESENT') {
          existing.present += 1
        }
      } else {
        subjectMap.set(record.subjectId, {
          subjectName: record.subject.subjectName,
          total: 1,
          present: record.status === 'PRESENT' ? 1 : 0,
        })
      }
    }

    const subjectWiseAttendance = Array.from(subjectMap.entries()).map(
      ([, data]) => {
        const percentage =
          data.total > 0 ? Math.round((data.present / data.total) * 100) : 0
        return {
          subject: data.subjectName,
          percentage,
        }
      }
    )

    // ==========================================
    // 3. Weekly trend (attendance % per ISO week)
    // ==========================================
    // Group records by ISO week using date calculation
    const weekMap = new Map<
      string,
      { total: number; present: number; weekStart: string }
    >()

    for (const record of allAttendance) {
      // Calculate the start of the week (Monday) for this date
      const dateObj = new Date(record.date + 'T00:00:00')
      const dayOfWeek = dateObj.getDay() // 0=Sunday, 1=Monday, ...
      // Shift so Monday=0, Sunday=6
      const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek
      const monday = new Date(dateObj)
      monday.setDate(monday.getDate() + mondayOffset)
      // Format as YYYY-MM-DD
      const weekKey = monday.toISOString().split('T')[0]

      const existing = weekMap.get(weekKey)
      if (existing) {
        existing.total += 1
        if (record.status === 'PRESENT') {
          existing.present += 1
        }
      } else {
        weekMap.set(weekKey, {
          total: 1,
          present: record.status === 'PRESENT' ? 1 : 0,
          weekStart: weekKey,
        })
      }
    }

    // Sort weeks chronologically and format
    const weeklyTrend = Array.from(weekMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([, data]) => {
        const percentage =
          data.total > 0
            ? Math.round((data.present / data.total) * 100)
            : 0
        return {
          week: data.weekStart,
          percentage,
        }
      })

    // ==========================================
    // Build the response
    // ==========================================
    return NextResponse.json({
      student: {
        id: student.id,
        name: student.user.name,
      },
      monthlySummary,
      subjectWiseAttendance,
      weeklyTrend,
    })
  } catch (error) {
    console.error('Get attendance chart data error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
