import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/student/attendance?studentId=xxx&subjectId=yyy&fromDate=2024-01-01&toDate=2024-03-01
// Returns attendance records for a student with optional filters.
// Also calculates overall and per-subject attendance percentages.
// Flags subjects where attendance < 75% with a warning.
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl

    // --- Required param ---
    const studentId = searchParams.get('studentId')
    if (!studentId) {
      return NextResponse.json(
        { error: 'studentId query parameter is required' },
        { status: 400 }
      )
    }

    // --- Optional filters ---
    const subjectId = searchParams.get('subjectId') || undefined
    const fromDate = searchParams.get('fromDate') || undefined
    const toDate = searchParams.get('toDate') || undefined

    // Validate date format if provided (YYYY-MM-DD)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/
    if (fromDate && !dateRegex.test(fromDate)) {
      return NextResponse.json(
        { error: 'fromDate must be in YYYY-MM-DD format' },
        { status: 400 }
      )
    }
    if (toDate && !dateRegex.test(toDate)) {
      return NextResponse.json(
        { error: 'toDate must be in YYYY-MM-DD format' },
        { status: 400 }
      )
    }

    // Verify student exists
    const student = await db.student.findUnique({
      where: { id: studentId },
      include: { user: true, class: true },
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // Build the where clause for filtering attendance records
    const whereClause: Record<string, unknown> = {
      studentId,
    }

    // Add subject filter if provided
    if (subjectId) {
      whereClause.subjectId = subjectId
    }

    // Add date range filters if provided
    if (fromDate || toDate) {
      whereClause.date = {
        ...(fromDate ? { gte: fromDate } : {}),
        ...(toDate ? { lte: toDate } : {}),
      }
    }

    // --- Fetch attendance records with subject info ---
    const attendanceRecords = await db.attendance.findMany({
      where: whereClause,
      include: {
        subject: {
          select: { id: true, subjectName: true },
        },
      },
      orderBy: { date: 'desc' },
    })

    // --- Calculate overall attendance percentage ---
    const totalCount = attendanceRecords.length
    const presentCount = attendanceRecords.filter(
      (r) => r.status === 'PRESENT'
    ).length
    const absentCount = totalCount - presentCount

    // Avoid division by zero
    const overallPercentage =
      totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0

    // --- Calculate per-subject attendance percentage ---
    // Group records by subject
    const subjectMap = new Map<
      string,
      { subjectName: string; total: number; present: number }
    >()

    for (const record of attendanceRecords) {
      const existing = subjectMap.get(record.subjectId)
      if (existing) {
        existing.total += 1
        if (record.status === 'PRESENT') {
          existing.present += 1
        }
      } else {
        subjectMap.set(record.subjectId, {
          subjectName: record.subject.subjectName,
          total: 1,
          present: record.status === 'PRESENT' ? 1 : 0,
        })
      }
    }

    // Convert map to array with percentages and warnings
    const subjectBreakdown = Array.from(subjectMap.entries()).map(
      ([subjectId, data]) => {
        const percentage =
          data.total > 0 ? Math.round((data.present / data.total) * 100) : 0
        return {
          subjectId,
          subjectName: data.subjectName,
          totalClasses: data.total,
          presentCount: data.present,
          absentCount: data.total - data.present,
          percentage,
          // Flag subjects with attendance below 75%
          warning: percentage < 75,
        }
      }
    )

    // Format attendance records for the response
    const formattedRecords = attendanceRecords.map((record) => ({
      id: record.id,
      date: record.date,
      status: record.status,
      subject: {
        id: record.subject.id,
        name: record.subject.subjectName,
      },
    }))

    return NextResponse.json({
      student: {
        id: student.id,
        name: student.user.name,
        rollNo: student.rollNo,
        class: student.class.className,
      },
      filters: {
        subjectId: subjectId || null,
        fromDate: fromDate || null,
        toDate: toDate || null,
      },
      records: formattedRecords,
      summary: {
        totalRecords: totalCount,
        presentCount,
        absentCount,
        overallPercentage,
        lowAttendanceWarning: overallPercentage < 75,
      },
      subjectBreakdown,
    })
  } catch (error) {
    console.error('Get student attendance error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
