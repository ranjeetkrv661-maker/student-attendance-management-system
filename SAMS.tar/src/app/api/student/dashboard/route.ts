import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/student/dashboard?studentId=xxx
// Returns a complete student dashboard summary including:
//   - Student info (name, roll no, class)
//   - Overall attendance percentage
//   - Total classes, present count, absent count
//   - Per-subject breakdown with percentages and warnings
//   - Recent 10 attendance records
//   - Low attendance warning flag (overall < 75%)
export async function GET(request: NextRequest) {
  try {
    const studentId = request.nextUrl.searchParams.get('studentId')

    if (!studentId) {
      return NextResponse.json(
        { error: 'studentId query parameter is required' },
        { status: 400 }
      )
    }

    // --- Fetch student with user and class info ---
    const student = await db.student.findUnique({
      where: { id: studentId },
      include: {
        user: true,
        class: true,
      },
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // --- Fetch ALL attendance records for this student ---
    const allAttendance = await db.attendance.findMany({
      where: { studentId },
      include: {
        subject: {
          select: { id: true, subjectName: true },
        },
      },
      orderBy: { date: 'desc' },
    })

    // ==========================================
    // Overall attendance stats
    // ==========================================
    const totalClasses = allAttendance.length
    const presentCount = allAttendance.filter(
      (r) => r.status === 'PRESENT'
    ).length
    const absentCount = totalClasses - presentCount

    // Avoid division by zero
    const overallPercentage =
      totalClasses > 0 ? Math.round((presentCount / totalClasses) * 100) : 0

    // ==========================================
    // Per-subject breakdown
    // ==========================================
    const subjectMap = new Map<
      string,
      { subjectName: string; total: number; present: number }
    >()

    for (const record of allAttendance) {
      const existing = subjectMap.get(record.subjectId)
      if (existing) {
        existing.total += 1
        if (record.status === 'PRESENT') {
          existing.present += 1
        }
      } else {
        subjectMap.set(record.subjectId, {
          subjectName: record.subject.subjectName,
          total: 1,
          present: record.status === 'PRESENT' ? 1 : 0,
        })
      }
    }

    // Build per-subject array with percentage and warning flag
    const subjectBreakdown = Array.from(subjectMap.entries()).map(
      ([subjectId, data]) => {
        const percentage =
          data.total > 0 ? Math.round((data.present / data.total) * 100) : 0
        return {
          subjectId,
          subjectName: data.subjectName,
          totalClasses: data.total,
          presentCount: data.present,
          absentCount: data.total - data.present,
          percentage,
          // Warning if attendance is below 75%
          warning: percentage < 75,
        }
      }
    )

    // ==========================================
    // Recent attendance records (last 10)
    // ==========================================
    const recentRecords = allAttendance.slice(0, 10).map((record) => ({
      id: record.id,
      date: record.date,
      status: record.status,
      subject: {
        id: record.subject.id,
        name: record.subject.subjectName,
      },
    }))

    // ==========================================
    // Build the dashboard response
    // ==========================================
    return NextResponse.json({
      student: {
        id: student.id,
        name: student.user.name,
        email: student.user.email,
        rollNo: student.rollNo,
        class: {
          id: student.class.id,
          name: student.class.className,
        },
      },
      overallStats: {
        totalClasses,
        presentCount,
        absentCount,
        overallPercentage,
        // Flag if overall attendance is below 75%
        lowAttendanceWarning: overallPercentage < 75,
      },
      subjectBreakdown,
      recentAttendance: recentRecords,
    })
  } catch (error) {
    console.error('Get student dashboard error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
