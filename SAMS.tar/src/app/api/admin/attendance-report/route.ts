// Admin API: Attendance Report - Get attendance data with filters and summary
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/attendance-report - Get attendance report with optional filters
// Query params: classId, subjectId, fromDate, toDate
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const classId = searchParams.get('classId')
    const subjectId = searchParams.get('subjectId')
    const fromDate = searchParams.get('fromDate') // Format: YYYY-MM-DD
    const toDate = searchParams.get('toDate')     // Format: YYYY-MM-DD

    // Build the where clause based on provided filters
    const where: Record<string, unknown> = {}

    if (classId) {
      where.classId = classId
    }
    if (subjectId) {
      where.subjectId = subjectId
    }
    if (fromDate || toDate) {
      // Date range filter on the date string field
      where.date = {}
      if (fromDate) {
        (where.date as Record<string, unknown>).gte = fromDate
      }
      if (toDate) {
        (where.date as Record<string, unknown>).lte = toDate
      }
    }

    // Fetch attendance records with related info
    const records = await db.attendance.findMany({
      where,
      include: {
        student: {
          include: {
            user: { select: { name: true } },
          },
        },
        subject: { select: { subjectName: true } },
        class: { select: { className: true } },
      },
      orderBy: [{ date: 'desc' }, { student: { rollNo: 'asc' } }],
    })

    // Shape the attendance records for the response
    const attendanceRecords = records.map((r) => ({
      id: r.id,
      studentId: r.studentId,
      studentName: r.student.user.name,
      rollNo: r.student.rollNo,
      subjectId: r.subjectId,
      subjectName: r.subject.subjectName,
      classId: r.classId,
      className: r.class.className,
      date: r.date,
      status: r.status,
    }))

    // Calculate summary statistics
    // Total unique class sessions (unique date + subjectId + classId combinations)
    const uniqueSessions = new Set<string>()
    records.forEach((r) => {
      uniqueSessions.add(`${r.date}-${r.subjectId}-${r.classId}`)
    })
    const totalClasses = uniqueSessions.size

    // Per-student attendance percentage
    const studentMap = new Map<
      string,
      {
        studentId: string
        studentName: string
        rollNo: string
        total: number
        present: number
      }
    >()

    records.forEach((r) => {
      const key = r.studentId
      if (!studentMap.has(key)) {
        studentMap.set(key, {
          studentId: r.studentId,
          studentName: r.student.user.name,
          rollNo: r.student.rollNo,
          total: 0,
          present: 0,
        })
      }
      const entry = studentMap.get(key)!
      entry.total += 1
      if (r.status === 'PRESENT') {
        entry.present += 1
      }
    })

    // Build student summaries with attendance percentage
    const studentSummary = Array.from(studentMap.values()).map((s) => ({
      studentId: s.studentId,
      studentName: s.studentName,
      rollNo: s.rollNo,
      totalRecords: s.total,
      presentCount: s.present,
      absentCount: s.total - s.present,
      attendancePercentage:
        s.total > 0 ? Math.round((s.present / s.total) * 100 * 100) / 100 : 0,
    }))

    return NextResponse.json({
      attendanceRecords,
      summary: {
        totalClasses,
        totalRecords: records.length,
        studentSummary,
      },
    })
  } catch (error) {
    console.error('Error fetching attendance report:', error)
    return NextResponse.json(
      { error: 'Failed to fetch attendance report' },
      { status: 500 }
    )
  }
}
