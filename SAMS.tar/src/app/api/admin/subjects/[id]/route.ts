// Admin API: Subject by ID - Update & Delete
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/admin/subjects/[id] - Update a subject
// Body: { subjectName }
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { subjectName } = body

    // Validate required fields
    if (!subjectName) {
      return NextResponse.json(
        { error: 'Subject name is required' },
        { status: 400 }
      )
    }

    // Check if subject exists
    const existingSubject = await db.subject.findUnique({ where: { id } })
    if (!existingSubject) {
      return NextResponse.json(
        { error: 'Subject not found' },
        { status: 404 }
      )
    }

    // Update the subject
    const updated = await db.subject.update({
      where: { id },
      data: { subjectName },
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error('Error updating subject:', error)
    return NextResponse.json(
      { error: 'Failed to update subject' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/subjects/[id] - Delete a subject by id
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check if subject exists
    const existingSubject = await db.subject.findUnique({ where: { id } })
    if (!existingSubject) {
      return NextResponse.json(
        { error: 'Subject not found' },
        { status: 404 }
      )
    }

    // Delete the subject (cascade will handle related records)
    await db.subject.delete({ where: { id } })

    return NextResponse.json({ message: 'Subject deleted successfully' })
  } catch (error) {
    console.error('Error deleting subject:', error)
    return NextResponse.json(
      { error: 'Failed to delete subject' },
      { status: 500 }
    )
  }
}
