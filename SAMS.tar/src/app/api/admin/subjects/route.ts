// Admin API: Subjects - List all subjects & Create a new subject
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/subjects - List all subjects
export async function GET() {
  try {
    const subjects = await db.subject.findMany({
      orderBy: { subjectName: 'asc' },
    })

    return NextResponse.json(subjects)
  } catch (error) {
    console.error('Error fetching subjects:', error)
    return NextResponse.json(
      { error: 'Failed to fetch subjects' },
      { status: 500 }
    )
  }
}

// POST /api/admin/subjects - Create a new subject
// Body: { subjectName }
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { subjectName } = body

    // Validate required fields
    if (!subjectName) {
      return NextResponse.json(
        { error: 'Subject name is required' },
        { status: 400 }
      )
    }

    // Create the subject
    const subject = await db.subject.create({
      data: { subjectName },
    })

    return NextResponse.json(subject, { status: 201 })
  } catch (error) {
    console.error('Error creating subject:', error)
    return NextResponse.json(
      { error: 'Failed to create subject' },
      { status: 500 }
    )
  }
}
