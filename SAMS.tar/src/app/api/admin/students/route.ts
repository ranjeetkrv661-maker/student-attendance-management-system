// Admin API: Students - List all students & Create a new student
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/students - List all students with their class info
export async function GET() {
  try {
    const students = await db.student.findMany({
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
        class: {
          select: { id: true, className: true },
        },
      },
      orderBy: { rollNo: 'asc' },
    })

    // Shape the response for easy frontend use
    const result = students.map((s) => ({
      id: s.id,
      userId: s.userId,
      name: s.user.name,
      email: s.user.email,
      rollNo: s.rollNo,
      classId: s.classId,
      className: s.class.className,
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching students:', error)
    return NextResponse.json(
      { error: 'Failed to fetch students' },
      { status: 500 }
    )
  }
}

// POST /api/admin/students - Create a new student
// Body: { name, email, password, rollNo, classId }
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, password, rollNo, classId } = body

    // Validate required fields
    if (!name || !email || !password || !rollNo || !classId) {
      return NextResponse.json(
        { error: 'All fields are required: name, email, password, rollNo, classId' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingUser = await db.user.findUnique({ where: { email } })
    if (existingUser) {
      return NextResponse.json(
        { error: 'A user with this email already exists' },
        { status: 409 }
      )
    }

    // Check if rollNo already exists
    const existingRollNo = await db.student.findUnique({ where: { rollNo } })
    if (existingRollNo) {
      return NextResponse.json(
        { error: 'A student with this roll number already exists' },
        { status: 409 }
      )
    }

    // Verify the class exists
    const classExists = await db.class.findUnique({ where: { id: classId } })
    if (!classExists) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Step 1: Create User with role "STUDENT"
    const user = await db.user.create({
      data: {
        name,
        email,
        password, // Plain text for college project
        role: 'STUDENT',
      },
    })

    // Step 2: Create Student profile linking to the user
    const student = await db.student.create({
      data: {
        userId: user.id,
        rollNo,
        classId,
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
        class: { select: { id: true, className: true } },
      },
    })

    return NextResponse.json(
      {
        id: student.id,
        userId: student.userId,
        name: student.user.name,
        email: student.user.email,
        rollNo: student.rollNo,
        classId: student.classId,
        className: student.class.className,
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating student:', error)
    return NextResponse.json(
      { error: 'Failed to create student' },
      { status: 500 }
    )
  }
}
