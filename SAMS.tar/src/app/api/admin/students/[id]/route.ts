// Admin API: Student by ID - Update & Delete
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/admin/students/[id] - Update a student
// Body: { name?, email?, rollNo?, classId? }
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { name, email, rollNo, classId } = body

    // Find the existing student
    const student = await db.student.findUnique({
      where: { id },
      include: { user: true },
    })

    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // If email is being changed, check for duplicates
    if (email && email !== student.user.email) {
      const emailExists = await db.user.findUnique({ where: { email } })
      if (emailExists) {
        return NextResponse.json(
          { error: 'A user with this email already exists' },
          { status: 409 }
        )
      }
    }

    // If rollNo is being changed, check for duplicates
    if (rollNo && rollNo !== student.rollNo) {
      const rollNoExists = await db.student.findUnique({ where: { rollNo } })
      if (rollNoExists) {
        return NextResponse.json(
          { error: 'A student with this roll number already exists' },
          { status: 409 }
        )
      }
    }

    // If classId is being changed, verify the class exists
    if (classId && classId !== student.classId) {
      const classExists = await db.class.findUnique({ where: { id: classId } })
      if (!classExists) {
        return NextResponse.json(
          { error: 'Class not found' },
          { status: 404 }
        )
      }
    }

    // Update the User record (name and/or email)
    if (name || email) {
      await db.user.update({
        where: { id: student.userId },
        data: {
          ...(name && { name }),
          ...(email && { email }),
        },
      })
    }

    // Update the Student record (rollNo and/or classId)
    if (rollNo || classId) {
      await db.student.update({
        where: { id },
        data: {
          ...(rollNo && { rollNo }),
          ...(classId && { classId }),
        },
      })
    }

    // Fetch the updated student with relations for the response
    const updated = await db.student.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, name: true, email: true } },
        class: { select: { id: true, className: true } },
      },
    })

    return NextResponse.json({
      id: updated!.id,
      userId: updated!.userId,
      name: updated!.user.name,
      email: updated!.user.email,
      rollNo: updated!.rollNo,
      classId: updated!.classId,
      className: updated!.class.className,
    })
  } catch (error) {
    console.error('Error updating student:', error)
    return NextResponse.json(
      { error: 'Failed to update student' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/students/[id] - Delete a student by id
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check if student exists
    const student = await db.student.findUnique({ where: { id } })
    if (!student) {
      return NextResponse.json(
        { error: 'Student not found' },
        { status: 404 }
      )
    }

    // Delete the student (cascade will handle User deletion)
    await db.student.delete({ where: { id } })

    return NextResponse.json({ message: 'Student deleted successfully' })
  } catch (error) {
    console.error('Error deleting student:', error)
    return NextResponse.json(
      { error: 'Failed to delete student' },
      { status: 500 }
    )
  }
}
