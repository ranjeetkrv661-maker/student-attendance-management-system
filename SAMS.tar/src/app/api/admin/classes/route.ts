// Admin API: Classes - List all classes & Create a new class
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/classes - List all classes with student count
export async function GET() {
  try {
    const classes = await db.class.findMany({
      include: {
        _count: {
          select: { students: true },
        },
      },
      orderBy: { className: 'asc' },
    })

    // Shape the response to include student count
    const result = classes.map((c) => ({
      id: c.id,
      className: c.className,
      studentCount: c._count.students,
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching classes:', error)
    return NextResponse.json(
      { error: 'Failed to fetch classes' },
      { status: 500 }
    )
  }
}

// POST /api/admin/classes - Create a new class
// Body: { className }
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { className } = body

    // Validate required fields
    if (!className) {
      return NextResponse.json(
        { error: 'Class name is required' },
        { status: 400 }
      )
    }

    // Create the class
    const newClass = await db.class.create({
      data: { className },
    })

    return NextResponse.json(
      {
        id: newClass.id,
        className: newClass.className,
        studentCount: 0,
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating class:', error)
    return NextResponse.json(
      { error: 'Failed to create class' },
      { status: 500 }
    )
  }
}
