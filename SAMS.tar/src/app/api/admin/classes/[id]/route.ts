// Admin API: Class by ID - Update & Delete
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/admin/classes/[id] - Update a class
// Body: { className }
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { className } = body

    // Validate required fields
    if (!className) {
      return NextResponse.json(
        { error: 'Class name is required' },
        { status: 400 }
      )
    }

    // Check if class exists
    const existingClass = await db.class.findUnique({ where: { id } })
    if (!existingClass) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Update the class
    const updated = await db.class.update({
      where: { id },
      data: { className },
      include: {
        _count: { select: { students: true } },
      },
    })

    return NextResponse.json({
      id: updated.id,
      className: updated.className,
      studentCount: updated._count.students,
    })
  } catch (error) {
    console.error('Error updating class:', error)
    return NextResponse.json(
      { error: 'Failed to update class' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/classes/[id] - Delete a class by id
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check if class exists
    const existingClass = await db.class.findUnique({ where: { id } })
    if (!existingClass) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Delete the class (cascade will handle related records)
    await db.class.delete({ where: { id } })

    return NextResponse.json({ message: 'Class deleted successfully' })
  } catch (error) {
    console.error('Error deleting class:', error)
    return NextResponse.json(
      { error: 'Failed to delete class' },
      { status: 500 }
    )
  }
}
