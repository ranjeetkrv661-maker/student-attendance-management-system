// Admin API: Assign Subjects - Manage teacher-subject-class assignments
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/assign-subjects - List all teacher-subject-class assignments
export async function GET() {
  try {
    const assignments = await db.teacherSubject.findMany({
      include: {
        teacher: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
        },
        subject: { select: { id: true, subjectName: true } },
        class: { select: { id: true, className: true } },
      },
      orderBy: { id: 'asc' },
    })

    // Shape the response for easy frontend use
    const result = assignments.map((a) => ({
      id: a.id,
      teacherId: a.teacherId,
      teacherName: a.teacher.user.name,
      subjectId: a.subjectId,
      subjectName: a.subject.subjectName,
      classId: a.classId,
      className: a.class.className,
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching assignments:', error)
    return NextResponse.json(
      { error: 'Failed to fetch assignments' },
      { status: 500 }
    )
  }
}

// POST /api/admin/assign-subjects - Assign a subject to a teacher for a class
// Body: { teacherId, subjectId, classId }
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { teacherId, subjectId, classId } = body

    // Validate required fields
    if (!teacherId || !subjectId || !classId) {
      return NextResponse.json(
        { error: 'All fields are required: teacherId, subjectId, classId' },
        { status: 400 }
      )
    }

    // Verify teacher exists
    const teacher = await db.teacher.findUnique({ where: { id: teacherId } })
    if (!teacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      )
    }

    // Verify subject exists
    const subject = await db.subject.findUnique({ where: { id: subjectId } })
    if (!subject) {
      return NextResponse.json(
        { error: 'Subject not found' },
        { status: 404 }
      )
    }

    // Verify class exists
    const classExists = await db.class.findUnique({ where: { id: classId } })
    if (!classExists) {
      return NextResponse.json(
        { error: 'Class not found' },
        { status: 404 }
      )
    }

    // Check if this assignment already exists
    const existing = await db.teacherSubject.findUnique({
      where: {
        teacherId_subjectId_classId: { teacherId, subjectId, classId },
      },
    })
    if (existing) {
      return NextResponse.json(
        { error: 'This assignment already exists' },
        { status: 409 }
      )
    }

    // Create the assignment
    const assignment = await db.teacherSubject.create({
      data: { teacherId, subjectId, classId },
      include: {
        teacher: {
          include: {
            user: { select: { name: true } },
          },
        },
        subject: { select: { subjectName: true } },
        class: { select: { className: true } },
      },
    })

    return NextResponse.json(
      {
        id: assignment.id,
        teacherId: assignment.teacherId,
        teacherName: assignment.teacher.user.name,
        subjectId: assignment.subjectId,
        subjectName: assignment.subject.subjectName,
        classId: assignment.classId,
        className: assignment.class.className,
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating assignment:', error)
    return NextResponse.json(
      { error: 'Failed to create assignment' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/assign-subjects - Remove an assignment
// Body: { teacherId, subjectId, classId }
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { teacherId, subjectId, classId } = body

    // Validate required fields
    if (!teacherId || !subjectId || !classId) {
      return NextResponse.json(
        { error: 'All fields are required: teacherId, subjectId, classId' },
        { status: 400 }
      )
    }

    // Check if this assignment exists
    const existing = await db.teacherSubject.findUnique({
      where: {
        teacherId_subjectId_classId: { teacherId, subjectId, classId },
      },
    })
    if (!existing) {
      return NextResponse.json(
        { error: 'Assignment not found' },
        { status: 404 }
      )
    }

    // Delete the assignment
    await db.teacherSubject.delete({
      where: {
        teacherId_subjectId_classId: { teacherId, subjectId, classId },
      },
    })

    return NextResponse.json({ message: 'Assignment removed successfully' })
  } catch (error) {
    console.error('Error removing assignment:', error)
    return NextResponse.json(
      { error: 'Failed to remove assignment' },
      { status: 500 }
    )
  }
}
