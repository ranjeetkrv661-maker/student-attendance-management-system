// Admin API: Teacher by ID - Update & Delete
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// PUT /api/admin/teachers/[id] - Update a teacher
// Body: { name?, email? }
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { name, email } = body

    // Find the existing teacher
    const teacher = await db.teacher.findUnique({
      where: { id },
      include: { user: true },
    })

    if (!teacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      )
    }

    // If email is being changed, check for duplicates
    if (email && email !== teacher.user.email) {
      const emailExists = await db.user.findUnique({ where: { email } })
      if (emailExists) {
        return NextResponse.json(
          { error: 'A user with this email already exists' },
          { status: 409 }
        )
      }
    }

    // Update the User record (name and/or email)
    if (name || email) {
      await db.user.update({
        where: { id: teacher.userId },
        data: {
          ...(name && { name }),
          ...(email && { email }),
        },
      })
    }

    // Fetch the updated teacher with relations for the response
    const updated = await db.teacher.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, name: true, email: true } },
        subjects: {
          include: {
            subject: { select: { id: true, subjectName: true } },
            class: { select: { id: true, className: true } },
          },
        },
      },
    })

    return NextResponse.json({
      id: updated!.id,
      userId: updated!.userId,
      name: updated!.user.name,
      email: updated!.user.email,
      assignments: updated!.subjects.map((ts) => ({
        id: ts.id,
        subjectId: ts.subjectId,
        subjectName: ts.subject.subjectName,
        classId: ts.classId,
        className: ts.class.className,
      })),
    })
  } catch (error) {
    console.error('Error updating teacher:', error)
    return NextResponse.json(
      { error: 'Failed to update teacher' },
      { status: 500 }
    )
  }
}

// DELETE /api/admin/teachers/[id] - Delete a teacher by id
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    // Check if teacher exists
    const teacher = await db.teacher.findUnique({ where: { id } })
    if (!teacher) {
      return NextResponse.json(
        { error: 'Teacher not found' },
        { status: 404 }
      )
    }

    // Delete the teacher (cascade will handle User and TeacherSubject deletions)
    await db.teacher.delete({ where: { id } })

    return NextResponse.json({ message: 'Teacher deleted successfully' })
  } catch (error) {
    console.error('Error deleting teacher:', error)
    return NextResponse.json(
      { error: 'Failed to delete teacher' },
      { status: 500 }
    )
  }
}
