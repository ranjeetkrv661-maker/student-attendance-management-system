// Admin API: Teachers - List all teachers & Create a new teacher
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/admin/teachers - List all teachers with their assigned subjects and classes
export async function GET() {
  try {
    const teachers = await db.teacher.findMany({
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
        subjects: {
          include: {
            subject: { select: { id: true, subjectName: true } },
            class: { select: { id: true, className: true } },
          },
        },
      },
      orderBy: { user: { name: 'asc' } },
    })

    // Shape the response for easy frontend use
    const result = teachers.map((t) => ({
      id: t.id,
      userId: t.userId,
      name: t.user.name,
      email: t.user.email,
      assignments: t.subjects.map((ts) => ({
        id: ts.id,
        subjectId: ts.subjectId,
        subjectName: ts.subject.subjectName,
        classId: ts.classId,
        className: ts.class.className,
      })),
    }))

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching teachers:', error)
    return NextResponse.json(
      { error: 'Failed to fetch teachers' },
      { status: 500 }
    )
  }
}

// POST /api/admin/teachers - Create a new teacher
// Body: { name, email, password }
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, password } = body

    // Validate required fields
    if (!name || !email || !password) {
      return NextResponse.json(
        { error: 'All fields are required: name, email, password' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingUser = await db.user.findUnique({ where: { email } })
    if (existingUser) {
      return NextResponse.json(
        { error: 'A user with this email already exists' },
        { status: 409 }
      )
    }

    // Step 1: Create User with role "TEACHER"
    const user = await db.user.create({
      data: {
        name,
        email,
        password, // Plain text for college project
        role: 'TEACHER',
      },
    })

    // Step 2: Create Teacher profile linking to the user
    const teacher = await db.teacher.create({
      data: {
        userId: user.id,
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
        subjects: {
          include: {
            subject: { select: { id: true, subjectName: true } },
            class: { select: { id: true, className: true } },
          },
        },
      },
    })

    return NextResponse.json(
      {
        id: teacher.id,
        userId: teacher.userId,
        name: teacher.user.name,
        email: teacher.user.email,
        assignments: [],
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Error creating teacher:', error)
    return NextResponse.json(
      { error: 'Failed to create teacher' },
      { status: 500 }
    )
  }
}
