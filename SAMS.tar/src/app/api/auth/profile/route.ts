import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/auth/profile?userId=xxx
// Returns full user profile with role-specific data:
//   - Students: class info + attendance stats
//   - Teachers: assigned subjects and classes
//   - Admin: just user info
export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId query parameter is required' },
        { status: 400 }
      )
    }

    // Find the user
    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Base response (exclude password)
    const baseProfile = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    }

    // ==========================================
    // If STUDENT: include class info + attendance stats
    // ==========================================
    if (user.role === 'STUDENT') {
      const student = await db.student.findUnique({
        where: { userId: user.id },
        include: {
          class: true,
        },
      })

      if (!student) {
        return NextResponse.json(baseProfile)
      }

      // Calculate attendance stats
      const totalClasses = await db.attendance.count({
        where: { studentId: student.id },
      })

      const presentClasses = await db.attendance.count({
        where: {
          studentId: student.id,
          status: 'PRESENT',
        },
      })

      const absentClasses = totalClasses - presentClasses
      const attendancePercentage =
        totalClasses > 0
          ? Math.round((presentClasses / totalClasses) * 100)
          : 0

      return NextResponse.json({
        ...baseProfile,
        student: {
          id: student.id,
          rollNo: student.rollNo,
          class: student.class,
        },
        attendanceStats: {
          totalClasses,
          presentClasses,
          absentClasses,
          attendancePercentage,
        },
      })
    }

    // ==========================================
    // If TEACHER: include assigned subjects and classes
    // ==========================================
    if (user.role === 'TEACHER') {
      const teacher = await db.teacher.findUnique({
        where: { userId: user.id },
        include: {
          subjects: {
            include: {
              subject: true,
              class: true,
            },
          },
        },
      })

      if (!teacher) {
        return NextResponse.json(baseProfile)
      }

      return NextResponse.json({
        ...baseProfile,
        teacher: {
          id: teacher.id,
          assignedSubjects: teacher.subjects.map((ts) => ({
            id: ts.id,
            subject: ts.subject,
            class: ts.class,
          })),
        },
      })
    }

    // ==========================================
    // If ADMIN: just return user info
    // ==========================================
    return NextResponse.json(baseProfile)
  } catch (error) {
    console.error('Get profile error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
