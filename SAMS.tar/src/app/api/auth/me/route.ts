import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

// GET /api/auth/me?userId=xxx
// Returns user details along with their role-specific data (student/teacher info)
export async function GET(request: NextRequest) {
  try {
    // Get userId from query parameters
    const userId = request.nextUrl.searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId query parameter is required' },
        { status: 400 }
      )
    }

    // Find the user by ID, including role-specific profiles
    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        student: {
          include: {
            class: true, // Include class info for students
          },
        },
        teacher: {
          include: {
            subjects: {
              include: {
                subject: true, // Include subject details
                class: true,   // Include class details
              },
            },
          },
        },
      },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Return user data (exclude password for security)
    const { password, ...safeUser } = user

    return NextResponse.json(safeUser)
  } catch (error) {
    console.error('Get current user error:', error)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500 }
    )
  }
}
