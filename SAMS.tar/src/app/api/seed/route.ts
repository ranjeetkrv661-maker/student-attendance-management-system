import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// POST /api/seed
// Seeds the database with sample Indian college data
// Uses upsert to avoid duplicate entries on repeated calls
export async function POST() {
  try {
    // ==========================================
    // 1. Create Admin User
    // ==========================================
    const admin = await db.user.upsert({
      where: { email: 'admin@college.edu' },
      update: {},
      create: {
        email: 'admin@college.edu',
        password: 'admin123',
        name: 'Admin',
        role: 'ADMIN',
      },
    })

    // ==========================================
    // 2. Create Classes
    // ==========================================
    const bca1 = await db.class.upsert({
      where: { id: 'class-bca1' },
      update: {},
      create: { id: 'class-bca1', className: 'BCA 1st Year' },
    })

    const bca2 = await db.class.upsert({
      where: { id: 'class-bca2' },
      update: {},
      create: { id: 'class-bca2', className: 'BCA 2nd Year' },
    })

    const bscIt = await db.class.upsert({
      where: { id: 'class-bscit' },
      update: {},
      create: { id: 'class-bscit', className: 'BSc IT' },
    })

    // ==========================================
    // 3. Create Subjects
    // ==========================================
    const dataStructures = await db.subject.upsert({
      where: { id: 'subject-ds' },
      update: {},
      create: { id: 'subject-ds', subjectName: 'Data Structures' },
    })

    const dbms = await db.subject.upsert({
      where: { id: 'subject-dbms' },
      update: {},
      create: { id: 'subject-dbms', subjectName: 'DBMS' },
    })

    const os = await db.subject.upsert({
      where: { id: 'subject-os' },
      update: {},
      create: { id: 'subject-os', subjectName: 'Operating System' },
    })

    const cn = await db.subject.upsert({
      where: { id: 'subject-cn' },
      update: {},
      create: { id: 'subject-cn', subjectName: 'Computer Networks' },
    })

    // ==========================================
    // 4. Create Teacher Users + Teacher Profiles
    // ==========================================

    // Rajesh Sir - Data Structures + BCA 1st Year
    const rajeshUser = await db.user.upsert({
      where: { email: 'rajesh@college.edu' },
      update: {},
      create: {
        email: 'rajesh@college.edu',
        password: 'teacher123',
        name: 'Rajesh Sir',
        role: 'TEACHER',
      },
    })

    const rajeshTeacher = await db.teacher.upsert({
      where: { id: 'teacher-rajesh' },
      update: {},
      create: {
        id: 'teacher-rajesh',
        userId: rajeshUser.id,
      },
    })

    // Assign Rajesh Sir to Data Structures + BCA 1st Year
    await db.teacherSubject.upsert({
      where: { id: 'ts-rajesh-ds-bca1' },
      update: {},
      create: {
        id: 'ts-rajesh-ds-bca1',
        teacherId: rajeshTeacher.id,
        subjectId: dataStructures.id,
        classId: bca1.id,
      },
    })

    // Anjali Ma'am - DBMS + BCA 1st Year
    const anjaliUser = await db.user.upsert({
      where: { email: 'anjali@college.edu' },
      update: {},
      create: {
        email: 'anjali@college.edu',
        password: 'teacher123',
        name: "Anjali Ma'am",
        role: 'TEACHER',
      },
    })

    const anjaliTeacher = await db.teacher.upsert({
      where: { id: 'teacher-anjali' },
      update: {},
      create: {
        id: 'teacher-anjali',
        userId: anjaliUser.id,
      },
    })

    // Assign Anjali Ma'am to DBMS + BCA 1st Year
    await db.teacherSubject.upsert({
      where: { id: 'ts-anjali-dbms-bca1' },
      update: {},
      create: {
        id: 'ts-anjali-dbms-bca1',
        teacherId: anjaliTeacher.id,
        subjectId: dbms.id,
        classId: bca1.id,
      },
    })

    // Suresh Sir - Operating System + BCA 2nd Year
    const sureshUser = await db.user.upsert({
      where: { email: 'suresh@college.edu' },
      update: {},
      create: {
        email: 'suresh@college.edu',
        password: 'teacher123',
        name: 'Suresh Sir',
        role: 'TEACHER',
      },
    })

    const sureshTeacher = await db.teacher.upsert({
      where: { id: 'teacher-suresh' },
      update: {},
      create: {
        id: 'teacher-suresh',
        userId: sureshUser.id,
      },
    })

    // Assign Suresh Sir to Operating System + BCA 2nd Year
    await db.teacherSubject.upsert({
      where: { id: 'ts-suresh-os-bca2' },
      update: {},
      create: {
        id: 'ts-suresh-os-bca2',
        teacherId: sureshTeacher.id,
        subjectId: os.id,
        classId: bca2.id,
      },
    })

    // ==========================================
    // 5. Create Student Users + Student Profiles
    // ==========================================

    // Rahul Kumar - BCA 1st Year
    const rahulUser = await db.user.upsert({
      where: { email: 'rahul@student.edu' },
      update: {},
      create: {
        email: 'rahul@student.edu',
        password: 'student123',
        name: 'Rahul Kumar',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-rahul' },
      update: {},
      create: {
        id: 'student-rahul',
        userId: rahulUser.id,
        rollNo: 'BCA001',
        classId: bca1.id,
      },
    })

    // Priya Sharma - BCA 1st Year
    const priyaUser = await db.user.upsert({
      where: { email: 'priya@student.edu' },
      update: {},
      create: {
        email: 'priya@student.edu',
        password: 'student123',
        name: 'Priya Sharma',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-priya' },
      update: {},
      create: {
        id: 'student-priya',
        userId: priyaUser.id,
        rollNo: 'BCA002',
        classId: bca1.id,
      },
    })

    // Aman Verma - BCA 1st Year
    const amanUser = await db.user.upsert({
      where: { email: 'aman@student.edu' },
      update: {},
      create: {
        email: 'aman@student.edu',
        password: 'student123',
        name: 'Aman Verma',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-aman' },
      update: {},
      create: {
        id: 'student-aman',
        userId: amanUser.id,
        rollNo: 'BCA003',
        classId: bca1.id,
      },
    })

    // Neha Singh - BCA 2nd Year
    const nehaUser = await db.user.upsert({
      where: { email: 'neha@student.edu' },
      update: {},
      create: {
        email: 'neha@student.edu',
        password: 'student123',
        name: 'Neha Singh',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-neha' },
      update: {},
      create: {
        id: 'student-neha',
        userId: nehaUser.id,
        rollNo: 'BCA004',
        classId: bca2.id,
      },
    })

    // Vikram Patel - BCA 2nd Year
    const vikramUser = await db.user.upsert({
      where: { email: 'vikram@student.edu' },
      update: {},
      create: {
        email: 'vikram@student.edu',
        password: 'student123',
        name: 'Vikram Patel',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-vikram' },
      update: {},
      create: {
        id: 'student-vikram',
        userId: vikramUser.id,
        rollNo: 'BCA005',
        classId: bca2.id,
      },
    })

    // Deepika Joshi - BCA 2nd Year
    const deepikaUser = await db.user.upsert({
      where: { email: 'deepika@student.edu' },
      update: {},
      create: {
        email: 'deepika@student.edu',
        password: 'student123',
        name: 'Deepika Joshi',
        role: 'STUDENT',
      },
    })

    await db.student.upsert({
      where: { id: 'student-deepika' },
      update: {},
      create: {
        id: 'student-deepika',
        userId: deepikaUser.id,
        rollNo: 'BCA006',
        classId: bca2.id,
      },
    })

    // ==========================================
    // 6. Create Sample Attendance Records
    //    For the past 2 weeks (14 days)
    //    Mix of PRESENT and ABSENT for each student
    // ==========================================

    // Get all students for attendance creation
    const allStudents = await db.student.findMany()

    // Define which subjects each class attends
    // BCA 1st Year: Data Structures, DBMS
    // BCA 2nd Year: Operating System
    const classSubjects: Record<string, string[]> = {
      [bca1.id]: [dataStructures.id, dbms.id],
      [bca2.id]: [os.id],
    }

    // Generate dates for the past 14 days
    const today = new Date()
    const attendanceRecords: {
      studentId: string
      classId: string
      subjectId: string
      date: string
      status: string
    }[] = []

    for (let dayOffset = 1; dayOffset <= 14; dayOffset++) {
      const date = new Date(today)
      date.setDate(date.getDate() - dayOffset)
      // Skip Sundays (getDay() === 0) - no college on Sunday!
      if (date.getDay() === 0) continue

      const dateStr = date.toISOString().split('T')[0] // Format: YYYY-MM-DD

      for (const student of allStudents) {
        const subjects = classSubjects[student.classId]
        if (!subjects) continue

        for (const subjectId of subjects) {
          // Use a simple pseudo-random based on student + date + subject to get consistent results
          // This creates a mix of PRESENT and ABSENT (~80% present, ~20% absent)
          const hash = (student.id.charCodeAt(0) + date.getDate() + subjectId.charCodeAt(0)) % 10
          const status = hash < 8 ? 'PRESENT' : 'ABSENT'

          attendanceRecords.push({
            studentId: student.id,
            classId: student.classId,
            subjectId,
            date: dateStr,
            status,
          })
        }
      }
    }

    // Create attendance records (skip if already exists due to unique constraint)
    let attendanceCreated = 0
    for (const record of attendanceRecords) {
      try {
        await db.attendance.create({
          data: record,
        })
        attendanceCreated++
      } catch {
        // Record already exists (unique constraint), skip it
      }
    }

    // ==========================================
    // Return success with counts
    // ==========================================
    return NextResponse.json({
      message: 'Database seeded successfully!',
      data: {
        users: { admin: 1, teachers: 3, students: 6 },
        classes: 3,
        subjects: 4,
        teacherSubjects: 3,
        attendanceRecords: attendanceCreated,
      },
    })
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json(
      { error: 'Failed to seed database. Check server logs.' },
      { status: 500 }
    )
  }
}
