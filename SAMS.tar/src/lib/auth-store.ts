// Auth store using Zustand for client-side state management
// Manages user authentication state across the application

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// User type from our API
export interface AuthUser {
  id: string
  name: string
  email: string
  role: 'ADMIN' | 'TEACHER' | 'STUDENT'
}

// Interface for the auth store
interface AuthStore {
  user: AuthUser | null
  isLoggedIn: boolean
  login: (user: AuthUser) => void
  logout: () => void
}

// Create the auth store with persistence (saves to localStorage)
export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isLoggedIn: false,
      // Login: save user data to store
      login: (user: AuthUser) => set({ user, isLoggedIn: true }),
      // Logout: clear user data
      logout: () => set({ user: null, isLoggedIn: false }),
    }),
    {
      name: 'attendance-auth-storage', // localStorage key
    }
  )
)
